# Banking Automation Framework

## Project Overview

This project automates the testing of the **ParaBank Online Banking Web Application** using Selenium WebDriver, Java, Cucumber BDD, JUnit, and Maven.

**Application URL:**
https://parabank.parasoft.com/parabank/index.htm

The framework validates critical banking functionalities such as Login, Account Management, Funds Transfer, Loan Requests, Customer Support, Navigation, and UI validations.

---

# Project Objective

The objective of this project is to automate the testing of the ParaBank Online Banking Application by simulating user actions and validating key functionalities.

The framework covers:

* Positive and Negative Test Scenarios
* UI Validation
* Navigation Testing
* Banking Transactions
* Loan Request Processing
* Customer Support Validation
* Cross-Browser Support
* Screenshot Capture
* Report Generation

---

# Technology Stack

### Programming Language

* Java

### Automation Tool

* Selenium WebDriver

### BDD Framework

* Cucumber

### Test Framework

* JUnit

### Build Tool

* Maven

### Reporting

* Extent Reports
* Cucumber HTML Reports

### Version Control

* Git
* GitHub

---

# Framework Design

```text
BankingAutomationProject
│
├── src/test/java
│   ├── base
│   ├── hooks
│   ├── pages
│   ├── stepdefinitions
│   ├── runner
│   └── utils
│
├── src/test/resources
│   ├── features
│   ├── config.properties
│   └── extent.properties
│
├── screenshots
│   ├── Success
│   └── Failed
│
├── test-output
│
├── pom.xml
├── README.md
└── .gitignore
```

---

# Modules Covered

## 1. Login Functionality

* Verify login with valid credentials
* Verify login with incorrect password
* Verify login with unregistered user
* Verify login with empty fields
* Verify login with invalid username format
* Verify password masking
* Verify session validation
* Verify Remember Me functionality

---

## 2. Account Functionality

* View checking account summary
* View savings account summary
* Validate balance updates
* View transaction history
* Validate transaction details
* Filter transactions
* Sort transactions

---

## 3. Funds Transfer

* Transfer funds between accounts
* Transfer with insufficient balance
* Transfer with empty fields
* Transfer to same account
* Transfer decimal amount
* Validate transfer confirmation

---

## 4. Loan Request

* Submit loan request with valid details
* Submit loan request with missing information
* Submit loan request exceeding eligibility
* Verify loan status

---

## 5. Customer Support

* Open customer support form
* Submit valid support request
* Submit support request with empty fields
* Validate acknowledgement message

---

## 6. Navigation and UI Testing

* Navigate through application pages
* Verify logo redirection
* Validate button visibility
* Validate button clickability
* Verify font consistency
* Verify alignment consistency
* Validate alert and popup messages

---

# Test Case Summary

| Module                | Test Cases |
| --------------------- | ---------- |
| Login Functionality   | 8          |
| Account Functionality | 7          |
| Funds Transfer        | 6          |
| Loan Request          | 4          |
| Customer Support      | 4          |
| Navigation & UI       | 5          |
| **Total**             | **34**     |

---

# Utilities Implemented

## DriverFactory

Responsible for:

* Browser Initialization
* Browser Management
* Driver Management
* Cross Browser Execution

Supported Browsers:

* Chrome
* Firefox
* Edge

---

## ConfigReader

Responsible for:

* Reading application URL
* Reading browser configuration
* Reading test data

---

## WaitUtils

Responsible for:

* Explicit Waits
* Synchronization
* Element Visibility
* Element Clickability
* Alert Handling

---

## ScreenshotUtil

Responsible for:

* Capturing Success Screenshots
* Capturing Failed Screenshots
* Storing Screenshots in Separate Folders

---

## Hooks

Responsible for:

* Setup Before Scenario Execution
* Teardown After Scenario Execution
* Failure Screenshot Capture

---

# Reports Generated

After execution the framework generates:

```text
test-output
│
├── cucumber-report.html
├── cucumber.json
│
├── SparkReport
│   └── Spark.html
│
└── PdfReport
    └── ExtentPdf.pdf
```

---

# Screenshots

## Success Screenshots

Stored under:

```text
screenshots/Success
```

Examples:

* Bank_Login_Success.png
* Bank_Account_Summary.png
* Bank_Fund_Transfer.png
* Bank_Loan_Request.png
* Bank_Customer_Support.png
* Spark_Report.png

---

## Failed Screenshots

Stored under:

```text
screenshots/Failed
```

Screenshots are automatically captured whenever a scenario fails.

---

# Observations and Findings

During automation testing of ParaBank, several observations were identified.

### Login Module

* ParaBank uses username-based authentication instead of email-based authentication.
* Invalid login scenarios do not always display dedicated validation messages.
* Assertions were updated based on actual application behavior.

### Funds Transfer Module

* The application allows transfers between the same source and destination account.
* Large transfer amounts are processed successfully in the demo environment.
* Certain validations expected in real banking applications are not implemented in the demo site.

### Empty Transfer Scenario

When transfer is attempted without entering required information, the application displays:

```text
Error!
An internal error has occurred and has been logged.
```

instead of field-level validation messages.

### Loan Request Module

* Loan approval and rejection behavior depends on demo environment configuration.
* Some business validations are not enforced.

### Transaction History

* Transaction history depends on transactions performed during the test execution.
* Additional transactions were executed to generate data for validation.

### Session Timeout

* Reliable session timeout validation is not available in the ParaBank demo environment.
* Scenario behavior differs from project documentation expectations.

### Browser Compatibility

* Tests executed successfully on Chrome.
* Selenium generated CDP compatibility warnings for Chrome version 149.
* These warnings did not affect test execution.

### UI and Navigation

* Navigation links loaded successfully.
* Page alignment and font consistency remained uniform across the application.

---

# Execution Summary

* Total Scenarios Implemented: 34
* Positive Test Cases: 18
* Negative Test Cases: 16
* Reporting: Extent Report & Cucumber HTML Report
* Screenshot Support: Success & Failure Screenshots
* Framework Pattern: Page Object Model (POM)

---

# How to Execute

## Run Complete Test Suite

Run:

```bash
mvn test
```

or execute:

```text
TestRunner.java
```

---

## Run Individual Feature Files

* login.feature
* account.feature
* transfer.feature
* loan.feature
* customerSupport.feature
* navigationUI.feature

---

# Configuration

Update:

```properties
src/test/resources/config.properties
```

```properties
url=https://parabank.parasoft.com/parabank/index.htm
browser=chrome

validUsername=your_username
validPassword=your_password
```

---

# GitHub Repository

Source code is maintained using Git and GitHub.

Repository contains:

* Source Code
* Feature Files
* Step Definitions
* Reports
* Screenshots
* README Documentation

---

# Author

**Bhuvaneswari Rajangam**

Automation Testing Project

**Tools:** Selenium WebDriver | Java | Cucumber BDD | Maven | JUnit | Extent Reports
