package utils;

import java.time.Duration;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import base.DriverFactory;

public class WaitUtils {

    public static WebElement waitForElementVisible(By locator) {

        WebDriverWait wait =
                new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));

        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public static WebElement waitForElementClickable(By locator) {

        WebDriverWait wait =
                new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));

        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public static Alert waitForAlert() {

        WebDriverWait wait =
                new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));

        return wait.until(ExpectedConditions.alertIsPresent());
    }

    public static void waitForPageTitleContains(String title) {

        WebDriverWait wait =
                new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));

        wait.until(ExpectedConditions.titleContains(title));
    }
}