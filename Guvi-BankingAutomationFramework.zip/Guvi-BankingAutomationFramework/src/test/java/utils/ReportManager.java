package utils;

public class ReportManager {

    public static void logInfo(String message) {
        System.out.println("[INFO] " + message);
    }

    public static void logPass(String message) {
        System.out.println("[PASS] " + message);
    }

    public static void logFail(String message) {
        System.out.println("[FAIL] " + message);
    }
}