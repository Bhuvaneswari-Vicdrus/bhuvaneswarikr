package pages;

import org.openqa.selenium.By;
import base.DriverFactory;
import utils.WaitUtils;

public class LoginPage {

    private By usernameField = By.name("username");
    private By passwordField = By.name("password");
    private By loginButton = By.xpath("//input[@value='Log In']");
    private By accountOverviewText = By.xpath("//h1[contains(text(),'Accounts Overview')]");
    private By errorMessage = By.xpath("//p[@class='error']");
    private By logoutLink = By.linkText("Log Out");
    private By loginPanel = By.id("leftPanel");

    public void enterUsername(String username) {
        WaitUtils.waitForElementVisible(usernameField).sendKeys(username);
    }

    public void enterPassword(String password) {
        WaitUtils.waitForElementVisible(passwordField).sendKeys(password);
    }

    public void clickLogin() {
        WaitUtils.waitForElementClickable(loginButton).click();
    }

    public void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLogin();
    }

    public boolean isAccountOverviewDisplayed() {
        return WaitUtils.waitForElementVisible(accountOverviewText).isDisplayed();
    }

    public String getErrorMessage() {
        return WaitUtils.waitForElementVisible(errorMessage).getText();
    }

    public boolean isPasswordMasked() {
        return DriverFactory.getDriver()
                .findElement(passwordField)
                .getAttribute("type")
                .equals("password");
    }

    public boolean isLogoutVisible() {
        return WaitUtils.waitForElementVisible(logoutLink).isDisplayed();
    }
    
    public String getLoginPanelText() {
        return WaitUtils.waitForElementVisible(loginPanel).getText();
    }
}