package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import base.DriverFactory;
import utils.WaitUtils;

public class LoanPage {

    private By requestLoanLink = By.linkText("Request Loan");
    private By loanAmount = By.id("amount");
    private By downPayment = By.id("downPayment");
    private By fromAccount = By.id("fromAccountId");
    private By applyNowButton = By.xpath("//input[@value='Apply Now']");
    private By loanResultTitle = By.xpath("//h1[contains(text(),'Loan Request Processed')]");
    private By loanStatus = By.id("loanStatus");

    public void openLoanPage() {
        WaitUtils.waitForElementClickable(requestLoanLink).click();
    }

    public void enterLoanAmount(String amount) {
        WaitUtils.waitForElementVisible(loanAmount).clear();
        DriverFactory.getDriver().findElement(loanAmount).sendKeys(amount);
    }

    public void enterDownPayment(String payment) {
        WaitUtils.waitForElementVisible(downPayment).clear();
        DriverFactory.getDriver().findElement(downPayment).sendKeys(payment);
    }

    public void selectAccount() {
        Select select = new Select(WaitUtils.waitForElementVisible(fromAccount));
        select.selectByIndex(0);
    }

    public void clickApplyNow() {
        WaitUtils.waitForElementClickable(applyNowButton).click();
    }

    public void submitLoanRequest(String amount, String payment) {
        openLoanPage();
        enterLoanAmount(amount);
        enterDownPayment(payment);
        selectAccount();
        clickApplyNow();
    }

    public boolean isLoanResultDisplayed() {
        return WaitUtils.waitForElementVisible(loanResultTitle).isDisplayed();
    }

    public String getLoanStatus() {
        return WaitUtils.waitForElementVisible(loanStatus).getText();
    }
}