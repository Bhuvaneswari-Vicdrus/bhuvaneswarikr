package pages;

import org.openqa.selenium.By;
import base.DriverFactory;
import utils.WaitUtils;

public class CustomerSupportPage {

    private By contactUsLink = By.linkText("Contact Us");
    private By nameField = By.id("name");
    private By emailField = By.id("email");
    private By phoneField = By.id("phone");
    private By messageField = By.id("message");
    private By sendButton = By.xpath("//input[@value='Send to Customer Care']");
    private By successMessage = By.xpath("//div[@id='rightPanel']//p");
    private By errorMessage = By.className("error");

    public void openContactUsPage() {
        WaitUtils.waitForElementClickable(contactUsLink).click();
    }

    public boolean isSupportFormDisplayed() {
        return WaitUtils.waitForElementVisible(nameField).isDisplayed();
    }

    public void enterSupportDetails(String name, String email, String phone, String message) {
        WaitUtils.waitForElementVisible(nameField).sendKeys(name);
        DriverFactory.getDriver().findElement(emailField).sendKeys(email);
        DriverFactory.getDriver().findElement(phoneField).sendKeys(phone);
        DriverFactory.getDriver().findElement(messageField).sendKeys(message);
    }

    public void clickSend() {
        WaitUtils.waitForElementClickable(sendButton).click();
    }

    public void submitValidSupportForm() {
        openContactUsPage();
        enterSupportDetails("Manju", "manju@test.com", "9999999999", "Need help with banking.");
        clickSend();
    }

    public void submitEmptySupportForm() {
        openContactUsPage();
        clickSend();
    }

    public String getSuccessMessage() {
        return WaitUtils.waitForElementVisible(successMessage).getText();
    }

    public String getErrorMessage() {
        return WaitUtils.waitForElementVisible(errorMessage).getText();
    }
}