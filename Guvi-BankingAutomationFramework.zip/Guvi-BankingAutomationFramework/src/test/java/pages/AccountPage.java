package pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import base.DriverFactory;
import utils.WaitUtils;

public class AccountPage {

    private By accountsOverviewLink = By.linkText("Accounts Overview");
    private By accountLinks = By.xpath("//table[@id='accountTable']//a");
    private By accountDetailsTitle = By.xpath("//h1[contains(text(),'Account Details')]");
    private By balance = By.id("balance");
    private By availableBalance = By.id("availableBalance");
    private By transactionTable = By.id("transactionTable");
    private By transactionRows = By.xpath("//table[@id='transactionTable']//tr");

    public void openAccountsOverview() {
        WaitUtils.waitForElementClickable(accountsOverviewLink).click();
    }

    public void selectFirstAccount() {
        WaitUtils.waitForElementClickable(accountLinks).click();
    }

    public boolean isAccountDetailsDisplayed() {
        return WaitUtils.waitForElementVisible(accountDetailsTitle).isDisplayed();
    }

    public boolean isBalanceDisplayed() {
        return WaitUtils.waitForElementVisible(balance).isDisplayed()
                && WaitUtils.waitForElementVisible(availableBalance).isDisplayed();
    }

    public boolean isTransactionHistoryDisplayed() {
        return WaitUtils.waitForElementVisible(transactionTable).isDisplayed();
    }

    public int getTransactionCount() {
        List<WebElement> rows = DriverFactory.getDriver().findElements(transactionRows);
        return rows.size();
    }

    public boolean transactionTableHasRows() {
        return getTransactionCount() > 1;
    }
}