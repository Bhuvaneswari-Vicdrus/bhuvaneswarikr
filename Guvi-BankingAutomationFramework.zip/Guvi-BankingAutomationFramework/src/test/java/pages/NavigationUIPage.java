package pages;

import org.openqa.selenium.By;
import base.DriverFactory;
import utils.WaitUtils;

public class NavigationUIPage {

    private By homeLink = By.linkText("home");
    private By aboutUsLink = By.linkText("About Us");
    private By servicesLink = By.linkText("Services");
    private By productsLink = By.linkText("Products");
    private By locationsLink = By.linkText("Locations");
    private By adminPageLink = By.linkText("Admin Page");
    private By logo = By.xpath("//img[@title='ParaBank']");
    private By loginButton = By.xpath("//input[@value='Log In']");
    private By body = By.tagName("body");

    public void clickHome() {
        WaitUtils.waitForElementClickable(homeLink).click();
    }

    public void clickLogo() {
        WaitUtils.waitForElementClickable(logo).click();
    }

    public boolean isHomePageDisplayed() {
        return WaitUtils.waitForElementVisible(loginButton).isDisplayed();
    }

    public void navigateThroughMajorLinks() {
        WaitUtils.waitForElementClickable(aboutUsLink).click();
        DriverFactory.getDriver().navigate().back();

        WaitUtils.waitForElementClickable(servicesLink).click();
        DriverFactory.getDriver().navigate().back();

        WaitUtils.waitForElementClickable(productsLink).click();
        DriverFactory.getDriver().navigate().back();

        WaitUtils.waitForElementClickable(locationsLink).click();
        DriverFactory.getDriver().navigate().back();

        WaitUtils.waitForElementClickable(adminPageLink).click();
        DriverFactory.getDriver().navigate().back();
    }

    public boolean isLoginButtonVisibleAndClickable() {
        return WaitUtils.waitForElementClickable(loginButton).isDisplayed();
    }

    public String getFontFamily() {
        return DriverFactory.getDriver().findElement(body).getCssValue("font-family");
    }

    public String getFontSize() {
        return DriverFactory.getDriver().findElement(body).getCssValue("font-size");
    }
}