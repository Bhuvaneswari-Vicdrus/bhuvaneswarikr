package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import base.DriverFactory;
import utils.WaitUtils;

public class TransferPage {

    private By transferFundsLink = By.linkText("Transfer Funds");
    private By amountField = By.id("amount");
    private By fromAccountDropdown = By.id("fromAccountId");
    private By toAccountDropdown = By.id("toAccountId");
    private By transferButton = By.xpath("//input[@value='Transfer']");
    private By transferCompleteTitle = By.xpath("//h1[contains(text(),'Transfer Complete')]");
    private By transferMessage = By.xpath("//div[@id='rightPanel']//p");
    private By rightPanel = By.id("rightPanel");
    private By errorTitle = By.xpath("//h1[contains(text(),'Error')]");

    public void openTransferFundsPage() {
        WaitUtils.waitForElementClickable(transferFundsLink).click();
    }

    public void enterAmount(String amount) {
        WaitUtils.waitForElementVisible(amountField).clear();
        DriverFactory.getDriver().findElement(amountField).sendKeys(amount);
    }

    public void selectFromAccountByIndex(int index) {
        Select select = new Select(WaitUtils.waitForElementVisible(fromAccountDropdown));
        select.selectByIndex(index);
    }

    public void selectToAccountByIndex(int index) {
        Select select = new Select(WaitUtils.waitForElementVisible(toAccountDropdown));
        select.selectByIndex(index);
    }

    public void clickTransfer() {
        WaitUtils.waitForElementClickable(transferButton).click();
    }

    public void transferAmount(String amount) {
        openTransferFundsPage();
        enterAmount(amount);
        selectFromAccountByIndex(0);
        selectToAccountByIndex(0);
        clickTransfer();
    }

    public boolean isTransferCompleteDisplayed() {
        return WaitUtils.waitForElementVisible(transferCompleteTitle).isDisplayed();
    }

    public String getTransferMessage() {
        return WaitUtils.waitForElementVisible(transferMessage).getText();
    }
    
    public String getRightPanelText() {
        return WaitUtils.waitForElementVisible(rightPanel).getText();
    }

    public boolean isErrorDisplayed() {
        return WaitUtils.waitForElementVisible(errorTitle).isDisplayed();
    }
}