package stepdefinitions;

import org.junit.Assert;
import io.cucumber.java.en.*;
import pages.TransferPage;
import utils.ScreenshotUtil;
import base.DriverFactory;

public class TransferSteps {

    TransferPage transferPage = new TransferPage();

    @When("user transfers valid amount between accounts")
    public void user_transfers_valid_amount_between_accounts() {
        transferPage.transferAmount("10");
    }

    @Then("transfer should be successful and balances should be updated")
    public void transfer_should_be_successful_and_balances_should_be_updated() {
        Assert.assertTrue(transferPage.isTransferCompleteDisplayed());
        ScreenshotUtil.captureScreenshot(DriverFactory.getDriver(), "Bank_Fund_Transfer");
    }

    @When("user transfers more than available balance")
    public void user_transfers_more_than_available_balance() {
        transferPage.transferAmount("999999");
    }

    @Then("transfer result should be displayed")
    public void transfer_result_should_be_displayed() {

        Assert.assertTrue(
                transferPage.isTransferCompleteDisplayed()
        );
    }

    @When("user submits transfer without required fields")
    public void user_submits_transfer_without_required_fields() {
        transferPage.openTransferFundsPage();
        transferPage.clickTransfer();
    }

    @Then("transfer validation error should be displayed")
    public void transfer_validation_error_should_be_displayed() {

        Assert.assertTrue(transferPage.isErrorDisplayed());

        Assert.assertTrue(
                transferPage.getRightPanelText()
                        .contains("An internal error has occurred")
        );
    }
    
    @When("user transfers amount to the same account")
    public void user_transfers_amount_to_the_same_account() {
        transferPage.transferAmount("5");
    }

    @Then("system should handle same account transfer request")
    public void system_should_handle_same_account_transfer_request() {
        Assert.assertTrue(transferPage.isTransferCompleteDisplayed());
    }

    @When("user transfers decimal amount within limit")
    public void user_transfers_decimal_amount_within_limit() {
        transferPage.transferAmount("10.50");
    }

    @Then("transfer should process correctly")
    public void transfer_should_process_correctly() {
        Assert.assertTrue(transferPage.isTransferCompleteDisplayed());
    }

    @When("user completes successful transfer")
    public void user_completes_successful_transfer() {
        transferPage.transferAmount("15");
    }

    @Then("transfer confirmation and new balances should be shown")
    public void transfer_confirmation_and_new_balances_should_be_shown() {
        Assert.assertTrue(transferPage.isTransferCompleteDisplayed());
    }
}