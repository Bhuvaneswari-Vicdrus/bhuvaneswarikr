package stepdefinitions;

import org.junit.Assert;
import io.cucumber.java.en.*;
import pages.NavigationUIPage;

public class NavigationUISteps {

    NavigationUIPage navigationUIPage = new NavigationUIPage();
    String fontFamily;
    String fontSize;

    @When("user clicks Home Accounts Transfer Loan and Contact pages")
    public void user_clicks_home_accounts_transfer_loan_and_contact_pages() {
        navigationUIPage.navigateThroughMajorLinks();
    }

    @Then("each respective page should load correctly")
    public void each_respective_page_should_load_correctly() {
        Assert.assertTrue(true);
    }

    @When("user clicks site logo")
    public void user_clicks_site_logo() {
        navigationUIPage.clickLogo();
    }

    @Then("user should be redirected to homepage")
    public void user_should_be_redirected_to_homepage() {
        Assert.assertTrue(navigationUIPage.isHomePageDisplayed());
    }

    @When("user views major action buttons")
    public void user_views_major_action_buttons() {
        // Home page already loaded
    }

    @Then("all major buttons should be visible and clickable")
    public void all_major_buttons_should_be_visible_and_clickable() {
        Assert.assertTrue(navigationUIPage.isLoginButtonVisibleAndClickable());
    }

    @When("user reviews UI layout across pages")
    public void user_reviews_ui_layout_across_pages() {
        fontFamily = navigationUIPage.getFontFamily();
        fontSize = navigationUIPage.getFontSize();
    }

    @Then("font spacing and alignment should be consistent")
    public void font_spacing_and_alignment_should_be_consistent() {
        Assert.assertFalse(fontFamily.isEmpty());
        Assert.assertFalse(fontSize.isEmpty());
    }

    @When("user triggers alert or popup messages")
    public void user_triggers_alert_or_popup_messages() {
        // Triggering login validation error
    }

    @Then("alerts should display correct content and styling")
    public void alerts_should_display_correct_content_and_styling() {
        Assert.assertTrue(true);
    }
}