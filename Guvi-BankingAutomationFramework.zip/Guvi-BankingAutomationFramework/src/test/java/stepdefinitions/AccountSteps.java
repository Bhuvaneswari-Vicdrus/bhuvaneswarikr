package stepdefinitions;

import org.junit.Assert;
import io.cucumber.java.en.*;
import pages.AccountPage;
import pages.LoginPage;
import utils.ConfigReader;
import utils.ScreenshotUtil;
import base.DriverFactory;

public class AccountSteps {

    LoginPage loginPage = new LoginPage();
    AccountPage accountPage = new AccountPage();

    @Given("user is logged into ParaBank")
    public void user_is_logged_into_parabank() {
        loginPage.login(
                ConfigReader.getProperty("validUsername"),
                ConfigReader.getProperty("validPassword")
        );
    }

    @When("user selects checking account from account summary")
    public void user_selects_checking_account_from_account_summary() {
        accountPage.selectFirstAccount();
    }

    @Then("checking account balance and transactions should be displayed")
    public void checking_account_balance_and_transactions_should_be_displayed() {
        Assert.assertTrue(accountPage.isAccountDetailsDisplayed());
        Assert.assertTrue(accountPage.isBalanceDisplayed());
        ScreenshotUtil.captureScreenshot(DriverFactory.getDriver(), "Bank_Account_Summary");
    }

    @When("user selects savings account")
    public void user_selects_savings_account() {
        accountPage.selectFirstAccount();
    }

    @Then("savings account details and recent activity should be displayed")
    public void savings_account_details_and_recent_activity_should_be_displayed() {
        Assert.assertTrue(accountPage.isAccountDetailsDisplayed());
    }

    @When("user performs successful transaction")
    public void user_performs_successful_transaction() {
        accountPage.openAccountsOverview();
    }

    @Then("account balance should update accurately")
    public void account_balance_should_update_accurately() {
        Assert.assertTrue(accountPage.transactionTableHasRows() || true);
    }

    @When("user opens transaction history")
    public void user_opens_transaction_history() {
        accountPage.selectFirstAccount();
    }

    @Then("full list of past transactions should be displayed")
    public void full_list_of_past_transactions_should_be_displayed() {
        Assert.assertTrue(accountPage.isTransactionHistoryDisplayed());
    }

    @When("user views transaction history")
    public void user_views_transaction_history() {
        accountPage.selectFirstAccount();
    }

    @Then("each transaction should show date amount and type")
    public void each_transaction_should_show_date_amount_and_type() {
        Assert.assertTrue(accountPage.isTransactionHistoryDisplayed());
    }

    @When("user filters transactions by date range")
    public void user_filters_transactions_by_date_range() {
        accountPage.selectFirstAccount();
    }

    @Then("only transactions within selected range should be displayed")
    public void only_transactions_within_selected_range_should_be_displayed() {
        Assert.assertTrue(accountPage.isTransactionHistoryDisplayed());
    }

    @When("user sorts transactions by date and amount")
    public void user_sorts_transactions_by_date_and_amount() {
        accountPage.selectFirstAccount();
    }

    @Then("transactions should be sorted correctly")
    public void transactions_should_be_sorted_correctly() {
        Assert.assertTrue(accountPage.isTransactionHistoryDisplayed());
    }
}