package stepdefinitions;

import org.junit.Assert;
import io.cucumber.java.en.*;
import pages.LoanPage;
import utils.ScreenshotUtil;
import base.DriverFactory;

public class LoanSteps {

    LoanPage loanPage = new LoanPage();

    @When("user submits loan request with valid details")
    public void user_submits_loan_request_with_valid_details() {
        loanPage.submitLoanRequest("1000", "100");
    }

    @Then("loan request should be submitted successfully")
    public void loan_request_should_be_submitted_successfully() {
        Assert.assertTrue(loanPage.isLoanResultDisplayed());
        ScreenshotUtil.captureScreenshot(DriverFactory.getDriver(), "Bank_Loan_Request");
    }

    @When("user submits loan request with missing information")
    public void user_submits_loan_request_with_missing_information() {
        loanPage.openLoanPage();
        loanPage.clickApplyNow();
    }

    @Then("loan validation errors should be displayed")
    public void loan_validation_errors_should_be_displayed() {
        Assert.assertTrue(true);
    }

    @When("user applies for loan beyond eligibility")
    public void user_applies_for_loan_beyond_eligibility() {
        loanPage.submitLoanRequest("9999999", "10");
    }

    @Then("loan rejection message should be displayed")
    public void loan_rejection_message_should_be_displayed() {
        Assert.assertTrue(loanPage.isLoanResultDisplayed());
    }

    @When("user checks loan application status")
    public void user_checks_loan_application_status() {
        loanPage.submitLoanRequest("1000", "100");
    }

    @Then("correct loan status should be displayed")
    public void correct_loan_status_should_be_displayed() {
        Assert.assertFalse(loanPage.getLoanStatus().isEmpty());
    }
}