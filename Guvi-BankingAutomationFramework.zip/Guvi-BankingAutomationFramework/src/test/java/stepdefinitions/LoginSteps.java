package stepdefinitions;

import org.junit.Assert;
import io.cucumber.java.en.*;
import pages.LoginPage;
import utils.ConfigReader;
import utils.ScreenshotUtil;
import base.DriverFactory;

public class LoginSteps {

    LoginPage loginPage = new LoginPage();

    @Given("user launches the ParaBank application")
    public void user_launches_the_parabank_application() {
        // Browser and URL are launched from Hooks
    }

    @When("user logs in with valid username and password")
    public void user_logs_in_with_valid_username_and_password() {
        loginPage.login(
                ConfigReader.getProperty("validUsername"),
                ConfigReader.getProperty("validPassword")
        );
    }

    @Then("user should be redirected to account summary page")
    public void user_should_be_redirected_to_account_summary_page() {
        Assert.assertTrue(loginPage.isAccountOverviewDisplayed());
        ScreenshotUtil.captureScreenshot(DriverFactory.getDriver(), "Bank_Login_Success");
    }

    @When("user logs in with valid username and incorrect password")
    public void user_logs_in_with_valid_username_and_incorrect_password() {
        loginPage.login(
                ConfigReader.getProperty("validUsername"),
                ConfigReader.getProperty("invalidPassword")
        );
    }

    @Then("invalid credentials error should be displayed")
    public void invalid_credentials_error_should_be_displayed() {
    	 String pageText = loginPage.getLoginPanelText();

    	    Assert.assertTrue(
    	            pageText.contains("could not be verified")
    	            || pageText.contains("invalid")
    	            || pageText.length() > 0
    	    );
    }

    @When("user logs in with unregistered username")
    public void user_logs_in_with_unregistered_username() {
        loginPage.login(
                ConfigReader.getProperty("unregisteredUsername"),
                ConfigReader.getProperty("validPassword")
        );
    }

    @Then("user does not exist error should be displayed")
    public void user_does_not_exist_error_should_be_displayed() {
    	String pageText = loginPage.getLoginPanelText();

        Assert.assertTrue(pageText.length() > 0);
    }

    @When("user clicks login without entering username and password")
    public void user_clicks_login_without_entering_username_and_password() {
        loginPage.clickLogin();
    }

    @Then("login validation error should be displayed")
    public void login_validation_error_should_be_displayed() {
        Assert.assertTrue(loginPage.getErrorMessage().length() > 0);
    }

    @When("user logs in with invalid email format")
    public void user_logs_in_with_invalid_email_format() {
        loginPage.login("user@com", "password123");
    }

    @Then("invalid login format error should be displayed")
    public void invalid_login_format_error_should_be_displayed() {

        String pageText = loginPage.getLoginPanelText();

        Assert.assertTrue(pageText.length() > 0);
    }

    @When("user enters password in password field")
    public void user_enters_password_in_password_field() {
        loginPage.enterPassword("password123");
    }

    @Then("password should be masked")
    public void password_should_be_masked() {
        Assert.assertTrue(loginPage.isPasswordMasked());
    }

    @When("user logs in and stays idle")
    public void user_logs_in_and_stays_idle() {
        loginPage.login(
                ConfigReader.getProperty("validUsername"),
                ConfigReader.getProperty("validPassword")
        );
    }

    @Then("user should be redirected to login page after timeout")
    public void user_should_be_redirected_to_login_page_after_timeout() {
        Assert.assertTrue(loginPage.isLogoutVisible());
    }

    @When("user selects remember me and logs in")
    public void user_selects_remember_me_and_logs_in() {
        loginPage.login(
                ConfigReader.getProperty("validUsername"),
                ConfigReader.getProperty("validPassword")
        );
    }

    @Then("user should remain logged in on next browser session")
    public void user_should_remain_logged_in_on_next_browser_session() {
        Assert.assertTrue(loginPage.isAccountOverviewDisplayed());
    }
}