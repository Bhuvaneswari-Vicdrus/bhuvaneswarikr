package stepdefinitions;

import org.junit.Assert;
import io.cucumber.java.en.*;
import pages.CustomerSupportPage;
import utils.ScreenshotUtil;
import base.DriverFactory;

public class CustomerSupportSteps {

    CustomerSupportPage supportPage = new CustomerSupportPage();

    @When("user opens customer support form")
    public void user_opens_customer_support_form() {
        supportPage.openContactUsPage();
    }

    @Then("support form should be displayed")
    public void support_form_should_be_displayed() {
        Assert.assertTrue(supportPage.isSupportFormDisplayed());
    }

    @When("user submits support form with valid information")
    public void user_submits_support_form_with_valid_information() {
        supportPage.submitValidSupportForm();
    }

    @Then("support form success message should be displayed")
    public void support_form_success_message_should_be_displayed() {
        Assert.assertTrue(supportPage.getSuccessMessage().length() > 0);
        ScreenshotUtil.captureScreenshot(DriverFactory.getDriver(), "Bank_Customer_Support");
    }

    @When("user submits support form with empty fields")
    public void user_submits_support_form_with_empty_fields() {
        supportPage.submitEmptySupportForm();
    }

    @Then("support form validation prompts should be displayed")
    public void support_form_validation_prompts_should_be_displayed() {
        Assert.assertTrue(supportPage.getErrorMessage().length() > 0);
    }

    @When("support form is submitted successfully")
    public void support_form_is_submitted_successfully() {
        supportPage.submitValidSupportForm();
    }

    @Then("acknowledgement message should be shown")
    public void acknowledgement_message_should_be_shown() {
        Assert.assertTrue(supportPage.getSuccessMessage().length() > 0);
    }
}