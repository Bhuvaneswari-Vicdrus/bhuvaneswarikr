Feature: Navigation and UI Testing

  Background:
    Given user launches the ParaBank application

  Scenario: TC30 Navigate through Home Accounts Transfer Loan Contact pages
    When user clicks Home Accounts Transfer Loan and Contact pages
    Then each respective page should load correctly

  Scenario: TC31 Verify logo link redirects to Home page
    When user clicks site logo
    Then user should be redirected to homepage

  Scenario: TC32 Validate visibility and clickability of all buttons
    When user views major action buttons
    Then all major buttons should be visible and clickable

  Scenario: TC33 Verify consistent font and alignment across pages
    When user reviews UI layout across pages
    Then font spacing and alignment should be consistent

  Scenario: TC34 Validate alert boxes and popup messages
    When user triggers alert or popup messages
    Then alerts should display correct content and styling