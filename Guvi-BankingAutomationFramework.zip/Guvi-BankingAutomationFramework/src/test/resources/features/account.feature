Feature: Account Functionality

  Background:
    Given user launches the ParaBank application
    And user logs in with valid username and password

  Scenario: TC09 View account summary of checking account
    When user selects checking account from account summary
    Then checking account balance and transactions should be displayed

  Scenario: TC10 View account summary of savings account
    When user selects savings account
    Then savings account details and recent activity should be displayed

  Scenario: TC11 Validate updated balance after transaction
    When user performs successful transaction
    Then account balance should update accurately

  Scenario: TC12 View full transaction history
    When user opens transaction history
    Then full list of past transactions should be displayed

  Scenario: TC13 Validate transaction list includes date amount and type
    When user views transaction history
    Then each transaction should show date amount and type

  Scenario: TC14 Filter transactions by date range
    When user filters transactions by date range
    Then only transactions within selected range should be displayed

  Scenario: TC15 Sort transactions by date and amount
    When user sorts transactions by date and amount
    Then transactions should be sorted correctly