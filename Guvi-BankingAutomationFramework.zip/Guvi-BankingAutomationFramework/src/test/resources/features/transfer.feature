Feature: Funds Transfer

  Background:
    Given user launches the ParaBank application
    And user logs in with valid username and password

  Scenario: TC16 Transfer funds between valid internal accounts
    When user transfers valid amount between accounts
    Then transfer should be successful and balances should be updated

  Scenario: TC17 Transfer funds with insufficient balance
    When user transfers more than available balance

  Scenario: TC18 Transfer funds with empty fields
    When user submits transfer without required fields
    Then transfer validation error should be displayed

  Scenario: TC19 Attempt to transfer to the same account
    When user transfers amount to the same account
    Then system should handle same account transfer request

  Scenario: TC20 Transfer large or decimal amount
    When user transfers decimal amount within limit
    Then transfer should process correctly

  Scenario: TC21 Validate transfer confirmation and updated balances
    When user completes successful transfer
    Then transfer confirmation and new balances should be shown