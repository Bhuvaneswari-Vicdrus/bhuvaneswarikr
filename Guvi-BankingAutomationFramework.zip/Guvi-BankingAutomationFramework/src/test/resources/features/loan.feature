Feature: Loan Request

  Background:
    Given user launches the ParaBank application
    And user logs in with valid username and password

  Scenario: TC22 Submit loan request with valid details
    When user submits loan request with valid details
    Then loan request should be submitted successfully

  Scenario: TC23 Submit loan request with missing information
    When user submits loan request with missing information
    Then loan validation errors should be displayed

  Scenario: TC24 Submit loan request exceeding limit
    When user applies for loan beyond eligibility
    Then loan rejection message should be displayed

  Scenario: TC25 Verify loan request status and result
    When user checks loan application status
    Then correct loan status should be displayed