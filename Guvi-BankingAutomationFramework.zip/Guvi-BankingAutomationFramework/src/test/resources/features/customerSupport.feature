Feature: Customer Support

  Background:
    Given user launches the ParaBank application

  Scenario: TC26 Access and open customer support form
    When user opens customer support form
    Then support form should be displayed

  Scenario: TC27 Submit form with valid user information
    When user submits support form with valid information
    Then support form success message should be displayed

  Scenario: TC28 Submit form with empty fields
    When user submits support form with empty fields
    Then support form validation prompts should be displayed

  Scenario: TC29 Verify form submission success message
    When support form is submitted successfully
    Then acknowledgement message should be shown