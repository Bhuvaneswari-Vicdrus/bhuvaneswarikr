Feature: Login Functionality

  Background:
    Given user launches the ParaBank application

  Scenario: TC01 Verify login with valid credentials
    When user logs in with valid username and password
    Then user should be redirected to account summary page

  Scenario: TC02 Verify login with incorrect password
    When user logs in with valid username and incorrect password
    Then invalid credentials error should be displayed

  Scenario: TC03 Verify login with unregistered user
    When user logs in with unregistered username
    Then user does not exist error should be displayed

  Scenario: TC04 Verify login with empty fields
    When user clicks login without entering username and password
    Then login validation error should be displayed

 Scenario: TC05 Verify login with invalid username format
    When user logs in with invalid email format
    Then invalid login format error should be displayed

  Scenario: TC06 Verify password field masks input
    When user enters password in password field
    Then password should be masked

 Scenario: TC07 Verify logout functionality
    When user logs in and stays idle
    Then user should be redirected to login page after timeout

  Scenario: TC08 Verify Remember Me functionality
    When user selects remember me and logs in
    Then user should remain logged in on next browser session