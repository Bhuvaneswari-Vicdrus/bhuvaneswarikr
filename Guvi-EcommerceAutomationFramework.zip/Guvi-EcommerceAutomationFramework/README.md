# E-commerce Automation Framework

## Project Objective

Automate testing of Demoblaze Online Shopping Web Application.

Website:
https://www.demoblaze.com/

## Tools Used

- Java
- Selenium WebDriver
- Cucumber BDD
- JUnit
- Maven
- Extent Reports

## Framework Structure

base
hooks
pages
stepdefinitions
runner
utils

## Test Modules

1. Login
2. Signup
3. Cart
4. Order
5. Product Navigation
6. Logout
7. UI & UX
8. Responsive Design

## Total Test Cases

25

## Execution

Run:

mvn test

or

Run TestRunner.java

## Reports

test-output/SparkReport/Spark.html