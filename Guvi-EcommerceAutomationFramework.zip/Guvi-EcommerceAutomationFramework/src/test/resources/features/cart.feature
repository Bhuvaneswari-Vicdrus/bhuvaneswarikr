Feature: Cart Functionality

  Background:
    Given user launches the Demoblaze application

  Scenario: TC09 Add product to cart
    When user selects a product
    And user clicks add to cart
    Then product added alert should be displayed

  Scenario: TC10 View cart with added product
    When user adds a product to cart
    And user navigates to cart page
    Then cart should display added product with title and price

  Scenario: TC11 Remove product from cart
    When user adds a product to cart
    And user navigates to cart page
    And user deletes product from cart
    Then product should be removed from cart

  Scenario: TC12 Add multiple products to cart
    When user adds multiple products to cart
    And user navigates to cart page
    Then cart should display all added products with correct total price