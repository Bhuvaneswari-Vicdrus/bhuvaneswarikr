Feature: Product Browsing and Navigation

  Background:
    Given user launches the Demoblaze application

  Scenario: TC16 Browse product categories
    When user clicks Phones category
    Then phone products should be displayed
    When user clicks Laptops category
    Then laptop products should be displayed
    When user clicks Monitors category
    Then monitor products should be displayed

  Scenario: TC17 View product details
    When user opens a product details page
    Then product image title description and price should be displayed

  Scenario: TC18 Verify home navigation
    When user clicks Home link
    Then homepage should be displayed with products

  Scenario: TC19 Navigate using navbar links
    When user clicks Home Cart and Contact links
    Then respective pages or popups should open correctly