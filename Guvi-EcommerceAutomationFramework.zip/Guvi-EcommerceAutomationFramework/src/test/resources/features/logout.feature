Feature: Logout Functionality

  Background:
    Given user launches the Demoblaze application

  Scenario: TC20 Verify logout after login
    When user logs in with valid username and password
    And user clicks logout button
    Then user should be logged out and login button should be visible