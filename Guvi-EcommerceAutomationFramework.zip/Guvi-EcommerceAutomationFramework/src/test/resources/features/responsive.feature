Feature: Responsive Design

  Background:
    Given user launches the Demoblaze application

  Scenario: TC25 Test horizontal scrolling on smaller screen
    When user opens application in mobile screen size
    Then page should not require horizontal scrolling