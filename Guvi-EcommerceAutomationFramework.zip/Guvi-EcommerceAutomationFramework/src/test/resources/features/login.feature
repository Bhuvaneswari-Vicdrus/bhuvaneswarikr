Feature: Login Functionality

  Background:
    Given user launches the Demoblaze application

  Scenario: TC01 Verify login with valid credentials
    When user logs in with valid username and password
    Then user should be logged in successfully

  Scenario: TC02 Verify login with incorrect password
    When user logs in with valid username and incorrect password
    Then login error alert should be displayed

  Scenario: TC03 Verify login with empty fields
    When user clicks login without entering username and password
    Then login required field alert should be displayed

  Scenario: TC04 Verify login with invalid email format
    When user logs in with invalid email format
    Then login validation alert should be displayed

  Scenario: TC05 Verify password field masks input
    When user enters password in login password field
    Then password should be masked