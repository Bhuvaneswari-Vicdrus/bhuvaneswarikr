Feature: UI and UX Testing

  Background:
    Given user launches the Demoblaze application

  Scenario: TC21 Verify alignment of product tiles
    When user views product grid
    Then product tiles should have consistent alignment

  Scenario: TC22 Check visibility of action buttons
    When user views action buttons
    Then add to cart login and signup buttons should be visible and clickable

  Scenario: TC23 Check font consistency across pages
    When user visits multiple application pages
    Then font style and size should be consistent

  Scenario: TC24 Test alert and popup styling
    When user triggers application alerts and popups
    Then alerts and popups should be readable and properly displayed