Feature: Sign-Up Functionality

  Background:
    Given user launches the Demoblaze application

  Scenario: TC06 Verify user sign-up with unique credentials
    When user signs up with unique username and password
    Then signup success alert should be displayed

  Scenario: TC07 Verify sign-up with existing username
    When user signs up with existing username and password
    Then existing user alert should be displayed

  Scenario: TC08 Verify sign-up with empty fields
    When user clicks signup without entering username and password
    Then signup required field alert should be displayed