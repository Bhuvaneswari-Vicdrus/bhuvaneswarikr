Feature: Order Functionality

  Background:
    Given user launches the Demoblaze application

  Scenario: TC13 Place order with valid details
    When user adds a product to cart
    And user navigates to cart page
    And user clicks place order
    And user enters valid order details
    And user clicks purchase
    Then order confirmation message should be displayed

  Scenario: TC14 Place order with empty form
    When user adds a product to cart
    And user navigates to cart page
    And user clicks place order
    And user clicks purchase without entering details
    Then order required field alert should be displayed

  Scenario: TC15 Verify order confirmation popup
    When user completes purchase with valid details
    Then confirmation popup should contain thank you message amount and id