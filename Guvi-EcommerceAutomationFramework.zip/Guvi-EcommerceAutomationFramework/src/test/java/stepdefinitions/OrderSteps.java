package stepdefinitions;

import org.junit.Assert;

import base.DriverFactory;
import io.cucumber.java.en.*;
import pages.CartPage;
import pages.OrderPage;
import utils.ScreenshotUtil;
import utils.WaitUtils;

public class OrderSteps {

    CartPage cartPage = new CartPage();
    OrderPage orderPage = new OrderPage();

    @When("user clicks place order")
    public void user_clicks_place_order() {
        orderPage.clickPlaceOrder();
    }

    @When("user enters valid order details")
    public void user_enters_valid_order_details() {
        orderPage.enterValidOrderDetails();
    }

    @When("user clicks purchase")
    public void user_clicks_purchase() {
        orderPage.clickPurchase();
    }

    @Then("order confirmation message should be displayed")
    public void order_confirmation_message_should_be_displayed() {
        Assert.assertTrue(orderPage.isConfirmationDisplayed());
        
        ScreenshotUtil.captureScreenshot(
                DriverFactory.getDriver(),
                "Order_Confirmation");
    }

    @When("user clicks purchase without entering details")
    public void user_clicks_purchase_without_entering_details() {
        orderPage.clickPurchase();
    }

    @Then("order required field alert should be displayed")
    public void order_required_field_alert_should_be_displayed() {
        String alertText = WaitUtils.waitForAlert().getText();
        Assert.assertTrue(alertText.contains("Please fill"));
        WaitUtils.waitForAlert().accept();
    }

    @When("user completes purchase with valid details")
    public void user_completes_purchase_with_valid_details() {
        cartPage.addFirstProductToCart();
        cartPage.goToCart();
        orderPage.clickPlaceOrder();
        orderPage.enterValidOrderDetails();
        orderPage.clickPurchase();
    }

    @Then("confirmation popup should contain thank you message amount and id")
    public void confirmation_popup_should_contain_thank_you_message_amount_and_id() {
    	 Assert.assertTrue(orderPage.isConfirmationDisplayed());

    	    String details = orderPage.getConfirmationDetails();

    	    Assert.assertTrue(details.contains("Id"));
    	    Assert.assertTrue(details.contains("Amount"));
    }
}