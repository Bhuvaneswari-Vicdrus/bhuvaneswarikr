package stepdefinitions;

import org.junit.Assert;
import io.cucumber.java.en.*;
import pages.LogoutPage;

public class LogoutSteps {

    LogoutPage logoutPage = new LogoutPage();

    @When("user clicks logout button")
    public void user_clicks_logout_button() {
        logoutPage.clickLogout();
    }

    @Then("user should be logged out and login button should be visible")
    public void user_should_be_logged_out_and_login_button_should_be_visible() {
        Assert.assertTrue(logoutPage.isLoginButtonVisible());
    }
}