package stepdefinitions;

import org.junit.Assert;
import io.cucumber.java.en.*;
import pages.SignupPage;
import utils.ConfigReader;
import utils.WaitUtils;

public class SignupSteps {

    SignupPage signupPage = new SignupPage();

    @When("user signs up with unique username and password")
    public void user_signs_up_with_unique_username_and_password() {
        String username = "user" + System.currentTimeMillis();
        signupPage.signup(username, ConfigReader.getProperty("signupPassword"));
    }

    @Then("signup success alert should be displayed")
    public void signup_success_alert_should_be_displayed() {
        String alertText = WaitUtils.waitForAlert().getText();
        Assert.assertTrue(alertText.contains("Sign up successful"));
        WaitUtils.waitForAlert().accept();
    }

    @When("user signs up with existing username and password")
    public void user_signs_up_with_existing_username_and_password() {
        signupPage.signup(
                ConfigReader.getProperty("existingUsername"),
                ConfigReader.getProperty("signupPassword")
        );
    }

    @Then("existing user alert should be displayed")
    public void existing_user_alert_should_be_displayed() {
        String alertText = WaitUtils.waitForAlert().getText();
        Assert.assertTrue(alertText.contains("already exist"));
        WaitUtils.waitForAlert().accept();
    }

    @When("user clicks signup without entering username and password")
    public void user_clicks_signup_without_entering_username_and_password() {
        signupPage.openSignupPopup();
        signupPage.clickSignup();
    }

    @Then("signup required field alert should be displayed")
    public void signup_required_field_alert_should_be_displayed() {
        String alertText = WaitUtils.waitForAlert().getText();
        Assert.assertTrue(alertText.contains("Please fill"));
        WaitUtils.waitForAlert().accept();
    }
}