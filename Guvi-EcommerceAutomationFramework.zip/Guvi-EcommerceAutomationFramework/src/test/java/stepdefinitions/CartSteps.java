package stepdefinitions;

import org.junit.Assert;

import base.DriverFactory;
import io.cucumber.java.en.*;
import pages.CartPage;
import utils.ScreenshotUtil;
import utils.WaitUtils;

public class CartSteps {

    CartPage cartPage = new CartPage();

    @When("user selects a product")
    public void user_selects_a_product() {
        cartPage.selectFirstProduct();
    }

    @When("user clicks add to cart")
    public void user_clicks_add_to_cart() {
        cartPage.clickAddToCart();
    }

    @Then("product added alert should be displayed")
    public void product_added_alert_should_be_displayed() {
        String alertText = WaitUtils.waitForAlert().getText();
        Assert.assertTrue(alertText.contains("Product added"));
        WaitUtils.waitForAlert().accept();
    }

    @When("user adds a product to cart")
    public void user_adds_a_product_to_cart() {
        cartPage.addFirstProductToCart();
    }

    @When("user navigates to cart page")
    public void user_navigates_to_cart_page() {
        cartPage.goToCart();
    }

    @Then("cart should display added product with title and price")
    public void cart_should_display_added_product_with_title_and_price() {
        Assert.assertTrue(cartPage.isProductDisplayedInCart());
        
        ScreenshotUtil.captureScreenshot(
                DriverFactory.getDriver(),
                "Cart_Page");
    }

    @When("user deletes product from cart")
    public void user_deletes_product_from_cart() {
        cartPage.deleteProduct();
    }

    @Then("product should be removed from cart")
    public void product_should_be_removed_from_cart() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertEquals(0, cartPage.getCartProductCount());
    }

    @When("user adds multiple products to cart")
    public void user_adds_multiple_products_to_cart() {
        cartPage.addMultipleProductsToCart();
    }

    @Then("cart should display all added products with correct total price")
    public void cart_should_display_all_added_products_with_correct_total_price() {
        Assert.assertTrue(cartPage.getCartProductCount() >= 2);
        Assert.assertFalse(cartPage.getTotalPrice().isEmpty());
    }
}