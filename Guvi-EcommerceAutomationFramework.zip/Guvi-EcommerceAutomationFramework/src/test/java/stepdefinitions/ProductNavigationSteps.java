package stepdefinitions;

import org.junit.Assert;
import io.cucumber.java.en.*;
import pages.ProductNavigationPage;

public class ProductNavigationSteps {

    ProductNavigationPage navigationPage = new ProductNavigationPage();

    @When("user clicks Phones category")
    public void user_clicks_phones_category() {
        navigationPage.clickPhones();
    }

    @Then("phone products should be displayed")
    public void phone_products_should_be_displayed() {
        Assert.assertTrue(navigationPage.isPhoneDisplayed());
    }

    @When("user clicks Laptops category")
    public void user_clicks_laptops_category() {
        navigationPage.clickLaptops();
    }

    @Then("laptop products should be displayed")
    public void laptop_products_should_be_displayed() {
        Assert.assertTrue(navigationPage.isLaptopDisplayed());
    }

    @When("user clicks Monitors category")
    public void user_clicks_monitors_category() {
        navigationPage.clickMonitors();
    }

    @Then("monitor products should be displayed")
    public void monitor_products_should_be_displayed() {
        Assert.assertTrue(navigationPage.isMonitorDisplayed());
    }

    @When("user opens a product details page")
    public void user_opens_a_product_details_page() {
        navigationPage.openProductDetails();
    }

    @Then("product image title description and price should be displayed")
    public void product_image_title_description_and_price_should_be_displayed() {
        Assert.assertTrue(navigationPage.areProductDetailsDisplayed());
    }

    @When("user clicks Home link")
    public void user_clicks_home_link() {
        navigationPage.clickHome();
    }

    @Then("homepage should be displayed with products")
    public void homepage_should_be_displayed_with_products() {
        Assert.assertTrue(navigationPage.isHomePageDisplayed());
    }

    @When("user clicks Home Cart and Contact links")
    public void user_clicks_home_cart_and_contact_links() {
        navigationPage.clickHomeCartContact();
    }

    @Then("respective pages or popups should open correctly")
    public void respective_pages_or_popups_should_open_correctly() {
        Assert.assertTrue(navigationPage.isContactPopupDisplayed());
    }
}