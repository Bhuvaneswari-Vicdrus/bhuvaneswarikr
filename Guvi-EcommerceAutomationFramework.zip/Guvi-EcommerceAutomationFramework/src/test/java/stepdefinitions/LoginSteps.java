package stepdefinitions;

import org.junit.Assert;

import base.DriverFactory;
import io.cucumber.java.en.*;
import pages.LoginPage;
import utils.ConfigReader;
import utils.ScreenshotUtil;
import utils.WaitUtils;

public class LoginSteps {

    LoginPage loginPage = new LoginPage();

    @Given("user launches the Demoblaze application")
    public void user_launches_the_demoblaze_application() {
        // Browser and URL are already launched in Hooks
    }

    @When("user logs in with valid username and password")
    public void user_logs_in_with_valid_username_and_password() {
        loginPage.login(
                ConfigReader.getProperty("validUsername"),
                ConfigReader.getProperty("validPassword")
        );
    }

    @Then("user should be logged in successfully")
    public void user_should_be_logged_in_successfully() {
        Assert.assertTrue(loginPage.isUserLoggedIn());
        
        ScreenshotUtil.captureScreenshot(
                DriverFactory.getDriver(),
                "Login_Success");
    }

    @When("user logs in with valid username and incorrect password")
    public void user_logs_in_with_valid_username_and_incorrect_password() {
        loginPage.login(
                ConfigReader.getProperty("validUsername"),
                ConfigReader.getProperty("invalidPassword")
        );
    }

    @Then("login error alert should be displayed")
    public void login_error_alert_should_be_displayed() {
        String alertText = WaitUtils.waitForAlert().getText();
        Assert.assertTrue(alertText.contains("Wrong password") || alertText.contains("User does not exist"));
        WaitUtils.waitForAlert().accept();
    }

    @When("user clicks login without entering username and password")
    public void user_clicks_login_without_entering_username_and_password() {
        loginPage.openLoginPopup();
        loginPage.clickLogin();
    }

    @Then("login required field alert should be displayed")
    public void login_required_field_alert_should_be_displayed() {
        String alertText = WaitUtils.waitForAlert().getText();
        Assert.assertTrue(alertText.contains("Please fill"));
        WaitUtils.waitForAlert().accept();
    }

    @When("user logs in with invalid email format")
    public void user_logs_in_with_invalid_email_format() {
        loginPage.login("user.com", "password123");
    }

    @Then("login validation alert should be displayed")
    public void login_validation_alert_should_be_displayed() {
        String alertText = WaitUtils.waitForAlert().getText();
        Assert.assertTrue(alertText.length() > 0);
        WaitUtils.waitForAlert().accept();
    }

    @When("user enters password in login password field")
    public void user_enters_password_in_login_password_field() {
        loginPage.openLoginPopup();
        loginPage.enterPassword("password123");
    }

    @Then("password should be masked")
    public void password_should_be_masked() {
        Assert.assertTrue(loginPage.isPasswordMasked());
    }
}