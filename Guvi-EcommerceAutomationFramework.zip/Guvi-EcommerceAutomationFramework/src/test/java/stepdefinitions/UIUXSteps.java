package stepdefinitions;

import org.junit.Assert;
import io.cucumber.java.en.*;
import pages.UIUXPage;
import utils.WaitUtils;

public class UIUXSteps {

    UIUXPage uiuxPage = new UIUXPage();
    String fontFamily;
    String fontSize;

    @When("user views product grid")
    public void user_views_product_grid() {
        // Home page already opened
    }

    @Then("product tiles should have consistent alignment")
    public void product_tiles_should_have_consistent_alignment() {
        Assert.assertTrue(uiuxPage.areProductTilesAligned());
    }

    @When("user views action buttons")
    public void user_views_action_buttons() {
        // Home page already opened
    }

    @Then("add to cart login and signup buttons should be visible and clickable")
    public void add_to_cart_login_and_signup_buttons_should_be_visible_and_clickable() {
        Assert.assertTrue(uiuxPage.areActionButtonsVisible());
    }

    @When("user visits multiple application pages")
    public void user_visits_multiple_application_pages() {
        fontFamily = uiuxPage.getBodyFontFamily();
        fontSize = uiuxPage.getBodyFontSize();
    }

    @Then("font style and size should be consistent")
    public void font_style_and_size_should_be_consistent() {
        Assert.assertFalse(fontFamily.isEmpty());
        Assert.assertFalse(fontSize.isEmpty());
    }

    @When("user triggers application alerts and popups")
    public void user_triggers_application_alerts_and_popups() {
        uiuxPage.triggerAlert();
    }

    @Then("alerts and popups should be readable and properly displayed")
    public void alerts_and_popups_should_be_readable_and_properly_displayed() {
        String alertText = WaitUtils.waitForAlert().getText();
        Assert.assertTrue(alertText.contains("Product added"));
        WaitUtils.waitForAlert().accept();
    }
}