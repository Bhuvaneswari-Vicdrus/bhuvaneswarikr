package stepdefinitions;

import org.junit.Assert;

import base.DriverFactory;
import io.cucumber.java.en.*;
import pages.ResponsivePage;
import utils.ScreenshotUtil;

public class ResponsiveSteps {

    ResponsivePage responsivePage = new ResponsivePage();

    @When("user opens application in mobile screen size")
    public void user_opens_application_in_mobile_screen_size() {
        responsivePage.setMobileScreenSize();
    }

    @Then("page should not require horizontal scrolling")
    public void page_should_not_require_horizontal_scrolling() {
        Assert.assertTrue(responsivePage.isHorizontalScrollAbsent());
        
        ScreenshotUtil.captureScreenshot(
                DriverFactory.getDriver(),
                "Responsive_View");
    }
}