package utils;

import java.io.FileInputStream;
import java.util.Properties;

public class ConfigReader {

    private static Properties properties;

    public static String getProperty(String key) {
        try {
            if (properties == null) {
                properties = new Properties();
                FileInputStream fis = new FileInputStream("src/test/resources/config.properties");
                properties.load(fis);
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to load config.properties");
        }

        return properties.getProperty(key);
    }
}