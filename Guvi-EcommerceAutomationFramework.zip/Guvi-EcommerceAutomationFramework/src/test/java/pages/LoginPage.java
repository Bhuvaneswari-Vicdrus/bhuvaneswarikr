package pages;

import org.openqa.selenium.By;
import base.DriverFactory;
import utils.WaitUtils;

public class LoginPage {

    private By loginLink = By.id("login2");
    private By usernameField = By.id("loginusername");
    private By passwordField = By.id("loginpassword");
    private By loginButton = By.xpath("//button[text()='Log in']");
    private By welcomeUser = By.id("nameofuser");

    public void openLoginPopup() {
        WaitUtils.waitForElementClickable(loginLink).click();
        WaitUtils.waitForElementVisible(usernameField);
    }

    public void enterUsername(String username) {
        WaitUtils.waitForElementVisible(usernameField).sendKeys(username);
    }

    public void enterPassword(String password) {
        WaitUtils.waitForElementVisible(passwordField).sendKeys(password);
    }

    public void clickLogin() {
        WaitUtils.waitForElementClickable(loginButton).click();
    }

    public void login(String username, String password) {
        openLoginPopup();
        enterUsername(username);
        enterPassword(password);
        clickLogin();
    }

    public boolean isUserLoggedIn() {
        return WaitUtils.waitForElementVisible(welcomeUser).isDisplayed();
    }

    public boolean isPasswordMasked() {
        return DriverFactory.getDriver()
                .findElement(passwordField)
                .getAttribute("type")
                .equals("password");
    }
}