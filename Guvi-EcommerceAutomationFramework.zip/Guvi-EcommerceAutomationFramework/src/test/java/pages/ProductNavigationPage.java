package pages;

import org.openqa.selenium.By;
import base.DriverFactory;
import utils.WaitUtils;

public class ProductNavigationPage {

    private By phones = By.linkText("Phones");
    private By laptops = By.linkText("Laptops");
    private By monitors = By.linkText("Monitors");
    private By samsungProduct = By.linkText("Samsung galaxy s6");
    private By macbookProduct = By.linkText("MacBook air");
    private By monitorProduct = By.linkText("Apple monitor 24");
    private By productTitle = By.className("name");
    private By productPrice = By.className("price-container");
    private By productDescription = By.id("more-information");
    private By homeLink = By.xpath("//a[contains(text(),'Home')]");
    private By cartLink = By.id("cartur");
    private By contactLink = By.xpath("//a[contains(text(),'Contact')]");
    private By contactEmail = By.id("recipient-email");

    public void clickPhones() {
        WaitUtils.waitForElementClickable(phones).click();
    }

    public boolean isPhoneDisplayed() {
        return WaitUtils.waitForElementVisible(samsungProduct).isDisplayed();
    }

    public void clickLaptops() {
        WaitUtils.waitForElementClickable(laptops).click();
    }

    public boolean isLaptopDisplayed() {
        return WaitUtils.waitForElementVisible(macbookProduct).isDisplayed();
    }

    public void clickMonitors() {
        WaitUtils.waitForElementClickable(monitors).click();
    }

    public boolean isMonitorDisplayed() {
        return WaitUtils.waitForElementVisible(monitorProduct).isDisplayed();
    }

    public void openProductDetails() {
        WaitUtils.waitForElementClickable(samsungProduct).click();
    }

    public boolean areProductDetailsDisplayed() {
        return WaitUtils.waitForElementVisible(productTitle).isDisplayed()
                && DriverFactory.getDriver().findElement(productPrice).isDisplayed()
                && DriverFactory.getDriver().findElement(productDescription).isDisplayed();
    }

    public void clickHome() {
        WaitUtils.waitForElementClickable(homeLink).click();
    }

    public boolean isHomePageDisplayed() {
        return WaitUtils.waitForElementVisible(samsungProduct).isDisplayed();
    }

    public void clickHomeCartContact() {
        clickHome();
        WaitUtils.waitForElementClickable(cartLink).click();
        WaitUtils.waitForElementClickable(contactLink).click();
    }

    public boolean isContactPopupDisplayed() {
        return WaitUtils.waitForElementVisible(contactEmail).isDisplayed();
    }
}