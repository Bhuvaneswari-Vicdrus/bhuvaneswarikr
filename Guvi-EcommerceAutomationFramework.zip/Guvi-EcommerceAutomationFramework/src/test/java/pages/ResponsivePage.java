package pages;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import base.DriverFactory;

public class ResponsivePage {

    public void setMobileScreenSize() {
        DriverFactory.getDriver().manage().window().setSize(new Dimension(375, 812));
    }

    public boolean isHorizontalScrollAbsent() {
        JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getDriver();

        Long bodyWidth = (Long) js.executeScript("return document.body.scrollWidth");
        Long windowWidth = (Long) js.executeScript("return window.innerWidth");

        return bodyWidth <= windowWidth;
    }
}