package pages;

import org.openqa.selenium.By;
import utils.WaitUtils;

public class LogoutPage {

    private By logoutButton = By.id("logout2");
    private By loginButton = By.id("login2");

    public void clickLogout() {
        WaitUtils.waitForElementClickable(logoutButton).click();
    }

    public boolean isLoginButtonVisible() {
        return WaitUtils.waitForElementVisible(loginButton).isDisplayed();
    }
}