package pages;

import org.openqa.selenium.By;
import base.DriverFactory;
import utils.WaitUtils;

public class SignupPage {

    private By signupLink = By.id("signin2");
    private By usernameField = By.id("sign-username");
    private By passwordField = By.id("sign-password");
    private By signupButton = By.xpath("//button[text()='Sign up']");

    public void openSignupPopup() {
        WaitUtils.waitForElementClickable(signupLink).click();
        WaitUtils.waitForElementVisible(usernameField);
    }

    public void enterUsername(String username) {
        DriverFactory.getDriver().findElement(usernameField).sendKeys(username);
    }

    public void enterPassword(String password) {
        DriverFactory.getDriver().findElement(passwordField).sendKeys(password);
    }

    public void clickSignup() {
        DriverFactory.getDriver().findElement(signupButton).click();
    }

    public void signup(String username, String password) {
        openSignupPopup();
        enterUsername(username);
        enterPassword(password);
        clickSignup();
    }
}