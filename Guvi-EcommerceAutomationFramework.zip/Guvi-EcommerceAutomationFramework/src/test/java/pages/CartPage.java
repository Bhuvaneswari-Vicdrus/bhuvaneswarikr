package pages;

import org.openqa.selenium.By;
import base.DriverFactory;
import utils.WaitUtils;

public class CartPage {

    private By firstProduct = By.linkText("Samsung galaxy s6");
    private By secondProduct = By.linkText("Nokia lumia 1520");
    private By addToCartButton = By.linkText("Add to cart");
    private By cartLink = By.id("cartur");
    private By cartRows = By.xpath("//tbody[@id='tbodyid']/tr");
    private By deleteButton = By.linkText("Delete");
    private By totalPrice = By.id("totalp");
    private By homeLink = By.xpath("//a[contains(text(),'Home')]");

    public void selectFirstProduct() {
        WaitUtils.waitForElementClickable(firstProduct).click();
    }

    public void clickAddToCart() {
        WaitUtils.waitForElementClickable(addToCartButton).click();
    }

    public void addFirstProductToCart() {
        selectFirstProduct();
        clickAddToCart();
        WaitUtils.waitForAlert().accept();
    }

    public void goToCart() {
        WaitUtils.waitForElementClickable(cartLink).click();
    }

    public boolean isProductDisplayedInCart() {
        WaitUtils.waitForElementVisible(cartRows);
        return DriverFactory.getDriver().findElements(cartRows).size() > 0;
    }

    public void deleteProduct() {
        WaitUtils.waitForElementClickable(deleteButton).click();
    }

    public int getCartProductCount() {
        return DriverFactory.getDriver().findElements(cartRows).size();
    }

    public String getTotalPrice() {
        return WaitUtils.waitForElementVisible(totalPrice).getText();
    }

    public void addMultipleProductsToCart() {
        selectFirstProduct();
        clickAddToCart();
        WaitUtils.waitForAlert().accept();

        WaitUtils.waitForElementClickable(homeLink).click();
        WaitUtils.waitForElementClickable(secondProduct).click();
        clickAddToCart();
        WaitUtils.waitForAlert().accept();
    }
}