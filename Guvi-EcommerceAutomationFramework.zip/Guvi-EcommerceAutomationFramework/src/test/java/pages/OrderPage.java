package pages;

import org.openqa.selenium.By;
import base.DriverFactory;
import utils.WaitUtils;

public class OrderPage {

    private By placeOrderButton = By.xpath("//button[text()='Place Order']");
    private By name = By.id("name");
    private By country = By.id("country");
    private By city = By.id("city");
    private By card = By.id("card");
    private By month = By.id("month");
    private By year = By.id("year");
    private By purchaseButton = By.xpath("//button[text()='Purchase']");
    private By confirmationTitle = By.xpath("//h2[contains(text(),'Thank you')]");
    private By confirmationDetails = By.xpath("//div[contains(@class,'sweet-alert')]//p");

    public void clickPlaceOrder() {
        WaitUtils.waitForElementClickable(placeOrderButton).click();
    }

    public void enterValidOrderDetails() {
        WaitUtils.waitForElementVisible(name).sendKeys("Manju");
        DriverFactory.getDriver().findElement(country).sendKeys("India");
        DriverFactory.getDriver().findElement(city).sendKeys("Bangalore");
        DriverFactory.getDriver().findElement(card).sendKeys("4111111111111111");
        DriverFactory.getDriver().findElement(month).sendKeys("12");
        DriverFactory.getDriver().findElement(year).sendKeys("2026");
    }

    public void clickPurchase() {
        WaitUtils.waitForElementClickable(purchaseButton).click();
    }

    public boolean isConfirmationDisplayed() {
        return WaitUtils.waitForElementVisible(confirmationTitle).isDisplayed();
    }

    public String getConfirmationDetails() {
        return DriverFactory.getDriver().findElement(confirmationDetails).getText();
    }
}