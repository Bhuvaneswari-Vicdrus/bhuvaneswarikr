package pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import base.DriverFactory;
import utils.WaitUtils;

public class UIUXPage {

    private By productCards = By.className("card");
    private By loginButton = By.id("login2");
    private By signupButton = By.id("signin2");
    private By samsungProduct = By.linkText("Samsung galaxy s6");
    private By addToCartButton = By.linkText("Add to cart");
    private By body = By.tagName("body");

    public boolean areProductTilesAligned() {
        List<WebElement> cards = DriverFactory.getDriver().findElements(productCards);

        if (cards.size() < 2) {
            return false;
        }

        int firstCardHeight = cards.get(0).getSize().getHeight();
        int secondCardHeight = cards.get(1).getSize().getHeight();

        return Math.abs(firstCardHeight - secondCardHeight) < 100;
    }

    public boolean areActionButtonsVisible() {
        boolean loginVisible = WaitUtils.waitForElementVisible(loginButton).isDisplayed();
        boolean signupVisible = DriverFactory.getDriver().findElement(signupButton).isDisplayed();

        WaitUtils.waitForElementClickable(samsungProduct).click();
        boolean addToCartVisible = WaitUtils.waitForElementVisible(addToCartButton).isDisplayed();

        return loginVisible && signupVisible && addToCartVisible;
    }

    public String getBodyFontFamily() {
        return DriverFactory.getDriver().findElement(body).getCssValue("font-family");
    }

    public String getBodyFontSize() {
        return DriverFactory.getDriver().findElement(body).getCssValue("font-size");
    }

    public void triggerAlert() {
        WaitUtils.waitForElementClickable(samsungProduct).click();
        WaitUtils.waitForElementClickable(addToCartButton).click();
    }
}