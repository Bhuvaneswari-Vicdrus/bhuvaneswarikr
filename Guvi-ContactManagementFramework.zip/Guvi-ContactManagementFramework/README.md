
Note: Kindly ignore the existing Guvi repository contents and folders that are unrelated to this project.
Any other folders or branches present in the repository were pushed previously by mistake and are not part of this assignment submission.

# Contact Management System Automation Framework

## Project Overview

This project automates the testing of the Contact Management System web application:

https://thinking-tester-contact-list.herokuapp.com/

The automation framework validates Login, Registration, Contact Management, Navigation, UI, and Input Validation functionalities using Selenium WebDriver and Cucumber BDD.

---

## Technology Stack

* Java 17
* Selenium WebDriver 4
* Cucumber BDD
* JUnit
* Maven
* Page Object Model (POM)
* Extent Reports (PDF & HTML)
* GitHub

---

## Framework Design

The framework follows the Page Object Model (POM) design pattern.

### Project Structure

```text
src/test/java

├── base
│   └── DriverFactory
│
├── hooks
│   └── Hooks
│
├── pages
│   ├── LoginPage
│   ├── SignupPage
│   ├── AddContactPage
│   ├── EditContactPage
│   ├── DeleteContactPage
│   ├── NavigationPage
│   ├── UIResponsivenessPage
│   └── InputValidationPage
│
├── stepdefinitions
│
├── runner
│   └── TestRunner
│
└── utils

src/test/resources

├── features
├── config.properties
└── extent.properties
```

---

## Test Coverage

### Login Functionality

* Verify login with valid credentials
* Verify login with incorrect password
* Verify login with empty fields
* Verify login with invalid email format
* Verify password masking

### Registration Functionality

* Verify sign-up with valid inputs
* Verify registration with already registered email
* Verify registration with blank fields
* Verify email format validation

### Add Contact Functionality

* Verify adding contact with valid details
* Verify required field validation
* Verify phone number validation
* Verify duplicate contact behavior
* Verify form reset behavior

### Edit Contact Functionality

* Verify editing an existing contact
* Verify cancel edit behavior
* Verify edit validation

### Delete Contact Functionality

* Verify deleting a contact
* Verify delete confirmation
* Verify deleted contact remains removed

### Session & Navigation

* Verify logout behavior
* Verify login persistence on refresh
* Verify direct URL access behavior
* Verify browser back behavior after logout

### UI & Responsiveness

* Verify contact form alignment
* Verify success indicators

### Input Validation & Security

* Verify max character validation
* Verify Unicode and non-English character support

---

## Test Execution

Run the framework using:

```bash
mvn test
```

or

Run:

```text
TestRunner.java
→ Run As
→ JUnit Test
```

---

## Reports

Execution reports are generated at:

```text
test-output/PdfReport/ExtentPdf.pdf
test-output/SparkReport/Spark.html
```

---

## Known Observations

### Scenario #9 – Password and Confirm Password Mismatch

Status: Not Applicable

Reason:

The Contact Management application does not provide a Confirm Password field on the Registration page.

Therefore, password mismatch validation cannot be automated because the required UI element is not available in the application.

---

### Scenario #24 – Direct Contact List Access

Expected:

User should be redirected to the Login page when navigating directly to `/contactList`.

Actual:

The application allows direct access to the Contact List page without authentication.

Observation:

This appears to be an application security behavior and has been documented.

---

### Scenario #25 – Browser Back Navigation After Logout

Expected:

User should remain on the Login page after logout even when clicking the browser back button.

Actual:

After logout, the application navigates to a blank `/logout` page.

Using the browser back button does not consistently redirect the user to the Login page.

Observation:

This behavior has been documented as an application implementation issue.

---

## Author

Bhuvaneswari K R

Automation Framework developed using Selenium WebDriver, Cucumber BDD, Maven, and Java.
