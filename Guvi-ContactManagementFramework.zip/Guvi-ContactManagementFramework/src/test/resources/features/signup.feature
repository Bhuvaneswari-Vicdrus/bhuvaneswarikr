Feature: Sign Up Functionality

Scenario: Verify sign-up with valid inputs
Given User is on signup page
When User enters new valid registration details
And User clicks signup submit button
Then Registration should be successful

Scenario: Verify registration with already registered email
Given User is on signup page
When User enters already registered email
And User clicks signup submit button
Then Signup error should be displayed

Scenario: Verify registration with blank fields
Given User is on signup page
When User clicks signup submit button
Then Signup validation should be displayed

Scenario: Verify password mismatch validation
Given User is on signup page
When Application does not provide confirm password field
Then Test case should be marked as Not Applicable

Scenario: Verify email format validation during sign-up
Given User is on signup page
When User enters invalid signup email format
And User clicks signup submit button
Then Signup validation should be displayed