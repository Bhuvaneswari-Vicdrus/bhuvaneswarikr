Feature: Add Contact Functionality

Scenario: Verify adding contact with all valid details
Given User is logged in and on contact list page
When User clicks add new contact button
And User enters all valid contact details
And User clicks contact submit button
Then Contact should be added and visible in contact list

Scenario: Verify adding contact with missing required fields
Given User is logged in and on contact list page
When User clicks add new contact button
And User clicks contact submit button
Then Contact validation message should be displayed

Scenario: Verify phone field accepts only numeric input
Given User is logged in and on contact list page
When User clicks add new contact button
And User enters alphabets in phone number field
And User clicks contact submit button
Then Phone field validation should be displayed

Scenario: Verify adding duplicate contact details
Given User is logged in and on contact list page
When User adds same contact details twice
Then Duplicate contact behavior should be documented

Scenario: Verify form resets after contact is added
Given User is logged in and on contact list page
When User clicks add new contact button
And User enters all valid contact details
And User clicks contact submit button
And User clicks add new contact button
Then Add contact form should be ready for new entry