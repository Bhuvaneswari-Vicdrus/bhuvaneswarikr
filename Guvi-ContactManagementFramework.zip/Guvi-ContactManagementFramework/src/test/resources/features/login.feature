Feature: Login Functionality

Scenario: Verify login with valid credentials
Given User is on login page
When User enters valid email and password
And User clicks login button
Then User should be redirected to contact list page

Scenario: Verify login with incorrect password
Given User is on login page
When User enters valid email and incorrect password
And User clicks login button
Then Login error message should be displayed

Scenario: Verify login with empty fields
Given User is on login page
When User clicks login button
Then Login validation message should be displayed

Scenario: Verify login with invalid email format
Given User is on login page
When User enters invalid email format
And User clicks login button
Then Login validation message should be displayed

Scenario: Verify password field masks input
Given User is on login page
When User enters password
Then Password field should mask input