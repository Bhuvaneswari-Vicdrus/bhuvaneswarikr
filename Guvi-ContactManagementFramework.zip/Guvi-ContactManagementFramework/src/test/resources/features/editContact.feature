Feature: Edit Contact Functionality

Scenario: Verify user can edit an existing contact
Given User is logged in and on contact list page
When User opens an existing contact
And User clicks edit contact button
And User updates phone number
And User clicks update contact button
Then Updated contact details should be displayed

Scenario: Verify canceling an edit
Given User is logged in and on contact list page
When User opens an existing contact
And User clicks edit contact button
And User changes phone number without saving
And User clicks cancel edit button
Then Original contact details should remain unchanged

Scenario: Verify validation during edit
Given User is logged in and on contact list page
When User opens an existing contact
And User clicks edit contact button
And User removes last name
And User clicks update contact button
Then Edit validation message should be displayed