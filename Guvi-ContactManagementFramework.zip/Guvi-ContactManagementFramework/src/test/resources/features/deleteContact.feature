Feature: Delete Contact Functionality

Scenario: Verify deleting a contact
Given User is logged in and on contact list page
When User opens a contact for deletion
And User clicks delete contact button
And User accepts delete confirmation
Then Contact should be removed from the list

Scenario: Verify delete confirmation
Given User is logged in and on contact list page
When User opens a contact for deletion
And User clicks delete contact button
Then Delete confirmation alert should appear

Scenario: Verify contact no longer appears after deletion
Given User is logged in and on contact list page
When User opens a contact for deletion
And User clicks delete contact button
And User accepts delete confirmation
And User refreshes contact list page
Then Deleted contact should not appear