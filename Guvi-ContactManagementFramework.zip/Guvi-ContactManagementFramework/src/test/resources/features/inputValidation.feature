Feature: Input Validation and Security

Scenario: Verify max character limit for contact fields
Given User is logged in and on contact list page
When User opens the add contact form for validation
And User enters more than 300 characters in first name
And User clicks validation submit button
Then Max character validation should be handled

Scenario: Verify Unicode and emojis in address field
Given User is logged in and on contact list page
When User opens the add contact form for validation
And User enters unicode and emoji characters in address field
And User clicks validation submit button
Then Unicode and emoji contact should be accepted or displayed