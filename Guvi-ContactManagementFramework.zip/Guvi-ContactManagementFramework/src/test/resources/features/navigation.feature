Feature: Session and Navigation Functionality

Scenario: Verify logout redirects to login page
Given User is logged in and on contact list page
When User clicks logout button
Then User should be redirected to login page

Scenario: Verify login state on refresh
Given User is logged in and on contact list page
When User refreshes the browser
Then Contact list page should remain displayed

Scenario: Verify login is required to access contact list
Given User is not logged in
When User navigates directly to contact list page
Then User should be redirected to login page

Scenario: Verify user cannot go back to contact list after logout using browser back button
Given User is logged in and on contact list page
When User clicks logout button
And User clicks browser back button
Then User should remain on login page