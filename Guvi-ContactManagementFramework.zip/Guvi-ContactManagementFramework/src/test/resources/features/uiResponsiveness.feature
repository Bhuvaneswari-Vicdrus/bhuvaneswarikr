Feature: UI and Responsiveness Functionality

Scenario: Verify alignment of fields on contact form
Given User is logged in and on contact list page
When User opens the add contact form
Then Contact form fields and buttons should be aligned

Scenario: Verify toast messages or success indicators
Given User is logged in and on contact list page
When User adds a contact for UI validation
Then Success indicator or contact list update should be shown