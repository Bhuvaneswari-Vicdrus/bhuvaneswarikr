package hooks;

import base.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {

    @Before
    public void setup() {

        DriverFactory.initializeDriver();
    }

    @After
    public void tearDown() {

        DriverFactory.quitDriver();
    }
}