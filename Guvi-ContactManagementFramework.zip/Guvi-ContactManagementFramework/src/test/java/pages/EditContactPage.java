package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import base.DriverFactory;

public class EditContactPage {

    By firstContact = By.cssSelector("tr.contactTableBodyRow");
    By editContactButton = By.id("edit-contact");
    By firstName = By.id("firstName");
    By lastName = By.id("lastName");
    By phone = By.id("phone");
    By submitButton = By.id("submit");
    By cancelButton = By.id("cancel");
    By errorMessage = By.id("error");
    By editTestContact = By.xpath("//td[contains(text(),'EditTest User')]");
    By email = By.id("email");

    String updatedPhone = "8885551212";
    String originalPhone = "";
    String updatedEmail = "updated" + System.currentTimeMillis() + "@test.com";

    public void openFirstContact() {
        DriverFactory.getDriver()
                .findElement(firstContact)
                .click();
    }

    public void clickEditContact() {
        DriverFactory.getDriver()
                .findElement(editContactButton)
                .click();
    }

    public void updatePhoneNumber() throws InterruptedException {

        WebElement firstNameElement = DriverFactory.getDriver().findElement(firstName);
        firstNameElement.click();
        firstNameElement.clear();
        firstNameElement.sendKeys("EditTest");
        firstNameElement.sendKeys(Keys.TAB);

        WebElement lastNameElement = DriverFactory.getDriver().findElement(lastName);
        lastNameElement.click();
        lastNameElement.clear();
        lastNameElement.sendKeys("User");
        lastNameElement.sendKeys(Keys.TAB);

        WebElement phoneElement = DriverFactory.getDriver().findElement(phone);
        phoneElement.click();
        phoneElement.clear();
        phoneElement.sendKeys("8885551212");
        phoneElement.sendKeys(Keys.TAB);

        Thread.sleep(1000);
    }

    public void changePhoneWithoutSaving() {
        WebElement phoneElement = DriverFactory.getDriver().findElement(phone);

        originalPhone = phoneElement.getAttribute("value");

        phoneElement.clear();
        phoneElement.sendKeys("7777777777");
    }

    public void removeLastName() {
        WebElement lastNameElement = DriverFactory.getDriver().findElement(lastName);

        lastNameElement.clear();
    }

    public void clickUpdateContact() {
        DriverFactory.getDriver()
                .findElement(submitButton)
                .click();
    }

    public void clickCancelEdit() {
        DriverFactory.getDriver()
                .findElement(cancelButton)
                .click();
    }

    public boolean isUpdatedPhoneDisplayed() {
        return DriverFactory.getDriver()
                .getPageSource()
                .contains(updatedPhone);
    }

    public boolean isOriginalPhoneUnchanged() {
        return !DriverFactory.getDriver()
                .getPageSource()
                .contains("7777777777");
    }

    public boolean isEditValidationDisplayed() {
        String lastNameValidation = DriverFactory.getDriver()
                .findElement(lastName)
                .getAttribute("validationMessage");

        List<WebElement> errors = DriverFactory.getDriver()
                .findElements(errorMessage);

        return !lastNameValidation.isEmpty()
                || errors.size() > 0;
    }
    
    public void openEditTestContact() {
        DriverFactory.getDriver()
                .findElement(editTestContact)
                .click();
    }
    
    public void updateEmail() {
        WebElement emailElement = DriverFactory.getDriver().findElement(email);
        emailElement.clear();
        emailElement.sendKeys(updatedEmail);
    }
    
    public void setValue(By locator, String value) {
        WebElement element = DriverFactory.getDriver().findElement(locator);

        JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getDriver();

        js.executeScript(
                "arguments[0].value=arguments[1];" +
                "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));" +
                "arguments[0].dispatchEvent(new Event('change', { bubbles: true }));",
                element,
                value
        );
    }
}