package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.DriverFactory;

public class NavigationPage {

    By logoutButton = By.id("logout");
    By loginButton = By.id("submit");
    By emailField = By.id("email");
    By contactListHeading = By.xpath("//h1[text()='Contact List']");

    public void clickLogout() {
        DriverFactory.getDriver().findElement(logoutButton).click();
    }

    public boolean isLoginPageDisplayed() {
        List<WebElement> emailFields = DriverFactory.getDriver().findElements(emailField);
        List<WebElement> loginButtons = DriverFactory.getDriver().findElements(loginButton);

        return emailFields.size() > 0 && loginButtons.size() > 0;
    }

    public void refreshBrowser() {
        DriverFactory.getDriver().navigate().refresh();
    }

    public boolean isContactListDisplayed() {
        List<WebElement> headings = DriverFactory.getDriver().findElements(contactListHeading);
        return headings.size() > 0 && headings.get(0).isDisplayed();
    }

    public void openContactListDirectly() {
        DriverFactory.getDriver()
                .get("https://thinking-tester-contact-list.herokuapp.com/contactList");
    }

    public void openBrowserBack() {
        DriverFactory.getDriver().navigate().back();
    }
}