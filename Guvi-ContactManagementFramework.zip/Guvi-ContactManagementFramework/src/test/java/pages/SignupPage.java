package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.DriverFactory;

public class SignupPage {

    By firstName = By.id("firstName");
    By lastName = By.id("lastName");
    By email = By.id("email");
    By password = By.id("password");
    By submit = By.id("submit");
    By errorMessage = By.id("error");
    By contactListHeading = By.xpath("//h1[text()='Contact List']");

    public void openSignupPage() {
        DriverFactory.getDriver()
                .get("https://thinking-tester-contact-list.herokuapp.com/addUser");
    }

    public void enterFirstName(String value) {
        DriverFactory.getDriver().findElement(firstName).sendKeys(value);
    }

    public void enterLastName(String value) {
        DriverFactory.getDriver().findElement(lastName).sendKeys(value);
    }

    public void enterEmail(String value) {
        DriverFactory.getDriver().findElement(email).sendKeys(value);
    }

    public void enterPassword(String value) {
        DriverFactory.getDriver().findElement(password).sendKeys(value);
    }

    public void clickSubmit() {
        DriverFactory.getDriver().findElement(submit).click();
    }

    public boolean isContactListDisplayed() {
        List<WebElement> headings = DriverFactory.getDriver()
                .findElements(contactListHeading);

        return headings.size() > 0 && headings.get(0).isDisplayed();
    }

    public boolean isErrorDisplayed() {
        List<WebElement> errors = DriverFactory.getDriver()
                .findElements(errorMessage);

        return errors.size() > 0 && errors.get(0).isDisplayed();
    }

    public boolean isValidationDisplayed() {
        String firstNameValidation = DriverFactory.getDriver()
                .findElement(firstName)
                .getAttribute("validationMessage");

        String lastNameValidation = DriverFactory.getDriver()
                .findElement(lastName)
                .getAttribute("validationMessage");

        String emailValidation = DriverFactory.getDriver()
                .findElement(email)
                .getAttribute("validationMessage");

        String passwordValidation = DriverFactory.getDriver()
                .findElement(password)
                .getAttribute("validationMessage");

        return !firstNameValidation.isEmpty()
                || !lastNameValidation.isEmpty()
                || !emailValidation.isEmpty()
                || !passwordValidation.isEmpty()
                || isErrorDisplayed();
    }
}