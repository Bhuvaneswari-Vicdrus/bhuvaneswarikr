package pages;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;

import base.DriverFactory;

public class DeleteContactPage {

    By firstContact = By.cssSelector("tr.contactTableBodyRow");
    By deleteButton = By.id("delete");
    By contactListHeading = By.xpath("//h1[text()='Contact List']");

    String deletedContactName = "";

    public void openContactForDeletion() throws InterruptedException {
        List<WebElement> contacts = DriverFactory.getDriver()
                .findElements(firstContact);

        if (contacts.size() > 0) {
            deletedContactName = contacts.get(0).getText();
            contacts.get(0).click();
            Thread.sleep(1000);
        }
    }

    public void clickDeleteButton() {
        DriverFactory.getDriver()
                .findElement(deleteButton)
                .click();
    }

    public boolean isDeleteAlertDisplayed() {
        try {
            DriverFactory.getDriver().switchTo().alert();
            return true;
        } catch (NoAlertPresentException e) {
            return false;
        }
    }

    public void acceptDeleteAlert() {
        Alert alert = DriverFactory.getDriver().switchTo().alert();
        alert.accept();
    }

    public boolean isContactListDisplayed() {
        return DriverFactory.getDriver()
                .findElements(contactListHeading)
                .size() > 0;
    }

    public void refreshPage() {
        DriverFactory.getDriver().navigate().refresh();
    }

    public boolean isDeletedContactRemoved() {
        return !DriverFactory.getDriver()
                .getPageSource()
                .contains(deletedContactName);
    }
}