package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import base.DriverFactory;

public class InputValidationPage {

    By addContactButton = By.id("add-contact");
    By firstName = By.id("firstName");
    By lastName = By.id("lastName");
    By email = By.id("email");
    By phone = By.id("phone");
    By street1 = By.id("street1");
    By city = By.id("city");
    By stateProvince = By.id("stateProvince");
    By postalCode = By.id("postalCode");
    By country = By.id("country");
    By submitButton = By.id("submit");
    By errorMessage = By.id("error");

    String unicodeAddress = "ಬೆಂಗಳೂರು 😊 🚀";

    public void openAddContactForm() {
        DriverFactory.getDriver().findElement(addContactButton).click();
    }

    public void enterLongFirstName() {
        String longName = "A".repeat(301);

        DriverFactory.getDriver().findElement(firstName).sendKeys(longName);
        DriverFactory.getDriver().findElement(lastName).sendKeys("Tester");
        DriverFactory.getDriver().findElement(email).sendKeys("longname@test.com");
        DriverFactory.getDriver().findElement(phone).sendKeys("9876543210");
    }

    public void enterUnicodeEmojiAddress() {
    	 DriverFactory.getDriver().findElement(firstName).sendKeys("Unicode");
    	    DriverFactory.getDriver().findElement(lastName).sendKeys("Tester");
    	    DriverFactory.getDriver().findElement(email).sendKeys("unicode" + System.currentTimeMillis() + "@test.com");
    	    DriverFactory.getDriver().findElement(phone).sendKeys("9876543210");

    	    WebElement addressField = DriverFactory.getDriver().findElement(street1);
    	    JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getDriver();

    	    js.executeScript(
    	            "arguments[0].value='ಬೆಂಗಳೂರು 😊 🚀';" +
    	            "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));" +
    	            "arguments[0].dispatchEvent(new Event('change', { bubbles: true }));",
    	            addressField
    	    );

    	    DriverFactory.getDriver().findElement(city).sendKeys("Bangalore");
    	    DriverFactory.getDriver().findElement(stateProvince).sendKeys("Karnataka");
    	    DriverFactory.getDriver().findElement(postalCode).sendKeys("560001");
    	    DriverFactory.getDriver().findElement(country).sendKeys("India");
    }

    public void clickSubmit() {
        DriverFactory.getDriver().findElement(submitButton).click();
    }

    public boolean isMaxCharacterHandled() {
        String firstNameValue = DriverFactory.getDriver()
                .findElement(firstName)
                .getAttribute("value");

        boolean restricted = firstNameValue.length() <= 300;

        boolean errorDisplayed = DriverFactory.getDriver()
                .findElements(errorMessage)
                .size() > 0;

        boolean notCrashed = DriverFactory.getDriver().getCurrentUrl().length() > 0;

        return restricted || errorDisplayed || notCrashed;
    }

    public boolean isUnicodeAcceptedOrDisplayed() {
        return DriverFactory.getDriver()
                .getPageSource()
                .contains("Unicode")
                || DriverFactory.getDriver()
                        .getPageSource()
                        .contains("ಬೆಂಗಳೂರು")
                || DriverFactory.getDriver()
                        .getCurrentUrl()
                        .contains("contactList");
    }
}