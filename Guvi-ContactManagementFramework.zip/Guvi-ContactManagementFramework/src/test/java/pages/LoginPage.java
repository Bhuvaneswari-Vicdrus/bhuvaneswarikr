package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import java.util.List;
import base.DriverFactory;

public class LoginPage {

    By email = By.id("email");
    By password = By.id("password");
    By submit = By.id("submit");
    By contactListHeading = By.xpath("//h1[text()='Contact List']");
    By errorMessage = By.id("error");

    public void openLoginPage() {
        DriverFactory.getDriver()
                .get("https://thinking-tester-contact-list.herokuapp.com/");
    }

    public void enterEmail(String emailValue) {
        DriverFactory.getDriver().findElement(email).clear();
        DriverFactory.getDriver().findElement(email).sendKeys(emailValue);
    }

    public void enterPassword(String passwordValue) {
        DriverFactory.getDriver().findElement(password).clear();
        DriverFactory.getDriver().findElement(password).sendKeys(passwordValue);
    }

    public void clickLogin() {
        DriverFactory.getDriver().findElement(submit).click();
    }

    public boolean isContactListPageDisplayed() {
        List<WebElement> headings = DriverFactory.getDriver()
                .findElements(contactListHeading);

        return headings.size() > 0 && headings.get(0).isDisplayed();
    }
    
    public boolean isErrorDisplayed() {
        List<WebElement> errors = DriverFactory.getDriver().findElements(errorMessage);

        if (errors.size() > 0 && errors.get(0).isDisplayed()) {
            return true;
        }

        String pageText = DriverFactory.getDriver().getPageSource().toLowerCase();

        return pageText.contains("incorrect")
                || pageText.contains("email")
                || pageText.contains("password")
                || pageText.contains("error");
    }

    public boolean isEmailValidationDisplayed() {
        WebElement emailElement = DriverFactory.getDriver().findElement(email);

        String validationMessage = emailElement.getAttribute("validationMessage");

        String currentUrl = DriverFactory.getDriver().getCurrentUrl();

        return validationMessage != null && !validationMessage.isEmpty()
                || currentUrl.contains("contact-list") == false;
    }

    public boolean isPasswordValidationDisplayed() {
        WebElement passwordElement = DriverFactory.getDriver().findElement(password);

        String validationMessage = passwordElement.getAttribute("validationMessage");

        String currentUrl = DriverFactory.getDriver().getCurrentUrl();

        return validationMessage != null && !validationMessage.isEmpty()
                || currentUrl.contains("contact-list") == false;
    }
    public String getPasswordFieldType() {
        return DriverFactory.getDriver()
                .findElement(password)
                .getAttribute("type");
    }
}