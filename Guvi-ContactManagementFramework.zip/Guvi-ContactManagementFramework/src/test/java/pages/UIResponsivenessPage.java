package pages;

import java.util.List;
import java.util.UUID;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.DriverFactory;

public class UIResponsivenessPage {

    By addContactButton = By.id("add-contact");
    By firstName = By.id("firstName");
    By lastName = By.id("lastName");
    By birthdate = By.id("birthdate");
    By email = By.id("email");
    By phone = By.id("phone");
    By street1 = By.id("street1");
    By city = By.id("city");
    By stateProvince = By.id("stateProvince");
    By postalCode = By.id("postalCode");
    By country = By.id("country");
    By submitButton = By.id("submit");
    By cancelButton = By.id("cancel");

    String uiContactName = "UI" + UUID.randomUUID().toString().substring(0, 5);
    

    public void openAddContactForm() {
        DriverFactory.getDriver().findElement(addContactButton).click();
    }

    public boolean areFieldsDisplayedAndAligned() {
        List<By> fields = List.of(
                firstName,
                lastName,
                birthdate,
                email,
                phone,
                street1,
                city,
                stateProvince,
                postalCode,
                country,
                submitButton,
                cancelButton
        );

        for (By field : fields) {
            WebElement element = DriverFactory.getDriver().findElement(field);

            if (!element.isDisplayed()) {
                return false;
            }

            if (element.getLocation().getX() < 0 || element.getLocation().getY() < 0) {
                return false;
            }
        }

        return true;
    }

    public void addContactForUIValidation() {
        DriverFactory.getDriver().findElement(addContactButton).click();

        DriverFactory.getDriver().findElement(firstName).sendKeys(uiContactName);
        DriverFactory.getDriver().findElement(lastName).sendKeys("Tester");
        DriverFactory.getDriver().findElement(birthdate).sendKeys("1995-01-01");
        DriverFactory.getDriver().findElement(email)
        .sendKeys("ui" + System.currentTimeMillis() + "@test.com");
        DriverFactory.getDriver().findElement(phone).sendKeys("9876543210");
        DriverFactory.getDriver().findElement(street1).sendKeys("Test Street");
        DriverFactory.getDriver().findElement(city).sendKeys("Bangalore");
        DriverFactory.getDriver().findElement(stateProvince).sendKeys("Karnataka");
        DriverFactory.getDriver().findElement(postalCode).sendKeys("560001");
        DriverFactory.getDriver().findElement(country).sendKeys("India");

        DriverFactory.getDriver().findElement(submitButton).click();
    }

    public boolean isSuccessIndicatorShown() {
    	String currentUrl = DriverFactory.getDriver().getCurrentUrl();
        String pageSource = DriverFactory.getDriver().getPageSource();

        System.out.println("After UI add URL: " + currentUrl);
        System.out.println("After UI add title: " + DriverFactory.getDriver().getTitle());

        return currentUrl.contains("contactList");
    }
}