package pages;

import java.util.List;
import java.util.UUID;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.DriverFactory;

public class AddContactPage {

    By addNewContactButton = By.id("add-contact");
    By firstName = By.id("firstName");
    By lastName = By.id("lastName");
    By birthdate = By.id("birthdate");
    By email = By.id("email");
    By phone = By.id("phone");
    By street1 = By.id("street1");
    By street2 = By.id("street2");
    By city = By.id("city");
    By stateProvince = By.id("stateProvince");
    By postalCode = By.id("postalCode");
    By country = By.id("country");
    By submitButton = By.id("submit");
    By errorMessage = By.id("error");

    String uniqueName = "Manju" + UUID.randomUUID().toString().substring(0, 5);

    public void clickAddNewContact() {
    	  DriverFactory.getDriver()
          .navigate()
          .refresh();

  DriverFactory.getDriver()
          .findElement(addNewContactButton)
          .click();
    }

    public void enterValidContactDetails() {
        DriverFactory.getDriver().findElement(firstName).sendKeys(uniqueName);
        DriverFactory.getDriver().findElement(lastName).sendKeys("Tester");
        DriverFactory.getDriver().findElement(birthdate).sendKeys("1995-01-01");
        DriverFactory.getDriver().findElement(email).sendKeys(uniqueName + "@test.com");
        DriverFactory.getDriver().findElement(phone).sendKeys("9876543210");
        DriverFactory.getDriver().findElement(street1).sendKeys("Street One");
        DriverFactory.getDriver().findElement(street2).sendKeys("Street Two");
        DriverFactory.getDriver().findElement(city).sendKeys("Bangalore");
        DriverFactory.getDriver().findElement(stateProvince).sendKeys("Karnataka");
        DriverFactory.getDriver().findElement(postalCode).sendKeys("560001");
        DriverFactory.getDriver().findElement(country).sendKeys("India");
    }

    public void enterDuplicateContactDetails() {
        DriverFactory.getDriver().findElement(firstName).sendKeys("Duplicate");
        DriverFactory.getDriver().findElement(lastName).sendKeys("Contact");
        DriverFactory.getDriver().findElement(email).sendKeys("duplicate@test.com");
        DriverFactory.getDriver().findElement(phone).sendKeys("9999999999");
    }

    public void enterAlphabetsInPhone() {
        DriverFactory.getDriver().findElement(firstName).sendKeys("Phone");
        DriverFactory.getDriver().findElement(lastName).sendKeys("Validation");
        DriverFactory.getDriver().findElement(phone).sendKeys("abcdef");
    }

    public void clickSubmit() {
        DriverFactory.getDriver().findElement(submitButton).click();
    }

    public boolean isContactVisible() {
        return DriverFactory.getDriver().getPageSource().contains(uniqueName);
    }

    public boolean isValidationDisplayed() {
        String firstNameValidation = DriverFactory.getDriver()
                .findElement(firstName).getAttribute("validationMessage");

        String lastNameValidation = DriverFactory.getDriver()
                .findElement(lastName).getAttribute("validationMessage");

        List<WebElement> errors = DriverFactory.getDriver().findElements(errorMessage);

        return !firstNameValidation.isEmpty()
                || !lastNameValidation.isEmpty()
                || errors.size() > 0;
    }

    public boolean isPhoneValidationDisplayed() {
        String phoneValue = DriverFactory.getDriver()
                .findElement(phone)
                .getAttribute("value");

        List<WebElement> errors = DriverFactory.getDriver().findElements(errorMessage);

        return !phoneValue.matches("\\d+")
                || errors.size() > 0;
    }

    public boolean isFormReadyForNewEntry() {
        return DriverFactory.getDriver().findElement(firstName).getAttribute("value").isEmpty();
    }
}