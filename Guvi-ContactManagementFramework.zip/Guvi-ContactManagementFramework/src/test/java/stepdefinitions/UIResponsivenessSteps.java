package stepdefinitions;

import org.junit.Assert;

import io.cucumber.java.en.*;
import pages.UIResponsivenessPage;

public class UIResponsivenessSteps {

    UIResponsivenessPage uiPage = new UIResponsivenessPage();

    @When("User opens the add contact form")
    public void user_opens_the_add_contact_form() {
        uiPage.openAddContactForm();
    }

    @Then("Contact form fields and buttons should be aligned")
    public void contact_form_fields_and_buttons_should_be_aligned() {
        Assert.assertTrue(uiPage.areFieldsDisplayedAndAligned());
    }

    @When("User adds a contact for UI validation")
    public void user_adds_a_contact_for_ui_validation() throws InterruptedException {
        uiPage.addContactForUIValidation();
        Thread.sleep(1000);
    }

    @Then("Success indicator or contact list update should be shown")
    public void success_indicator_or_contact_list_update_should_be_shown() {
        Assert.assertTrue(uiPage.isSuccessIndicatorShown());
    }
}