package stepdefinitions;

import org.junit.Assert;

import io.cucumber.java.en.*;
import pages.InputValidationPage;

public class InputValidationSteps {

    InputValidationPage validationPage = new InputValidationPage();

    @When("User opens the add contact form for validation")
    public void user_opens_the_add_contact_form_for_validation() {
        validationPage.openAddContactForm();
    }

    @When("User enters more than 300 characters in first name")
    public void user_enters_more_than_300_characters_in_first_name() {
        validationPage.enterLongFirstName();
    }

    @When("User clicks validation submit button")
    public void user_clicks_validation_submit_button() throws InterruptedException {
        validationPage.clickSubmit();
        Thread.sleep(1000);
    }

    @Then("Max character validation should be handled")
    public void max_character_validation_should_be_handled() {
        Assert.assertTrue(validationPage.isMaxCharacterHandled());
    }

    @When("User enters unicode and emoji characters in address field")
    public void user_enters_unicode_and_emoji_characters_in_address_field() {
        validationPage.enterUnicodeEmojiAddress();
    }

    @Then("Unicode and emoji contact should be accepted or displayed")
    public void unicode_and_emoji_contact_should_be_accepted_or_displayed() {
        Assert.assertTrue(validationPage.isUnicodeAcceptedOrDisplayed());
    }
}