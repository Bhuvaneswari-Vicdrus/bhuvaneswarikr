package stepdefinitions;

import java.util.UUID;

import org.junit.Assert;

import io.cucumber.java.en.*;
import pages.SignupPage;

public class SignupSteps {

    SignupPage signupPage = new SignupPage();

    String uniqueEmail = "manju"
            + UUID.randomUUID().toString().substring(0, 5)
            + "@test.com";

    @Given("User is on signup page")
    public void user_is_on_signup_page() {
        signupPage.openSignupPage();
    }

    @When("User enters new valid registration details")
    public void user_enters_new_valid_registration_details() {
        signupPage.enterFirstName("Manju");
        signupPage.enterLastName("Tester");
        signupPage.enterEmail(uniqueEmail);
        signupPage.enterPassword("Test@12345");
    }

    @When("User enters already registered email")
    public void user_enters_already_registered_email() {
        signupPage.enterFirstName("Manju");
        signupPage.enterLastName("Tester");
        signupPage.enterEmail("12testmailid@gmail.com");
        signupPage.enterPassword("Test@12345");
    }

    @When("User enters different password and confirm password")
    public void user_enters_different_password_and_confirm_password() {
        signupPage.enterFirstName("Manju");
        signupPage.enterLastName("Tester");
        signupPage.enterEmail("mismatch" + UUID.randomUUID().toString().substring(0, 5) + "@test.com");
        signupPage.enterPassword("Test@12345");
    }

    @When("User enters invalid signup email format")
    public void user_enters_invalid_signup_email_format() {
        signupPage.enterFirstName("Manju");
        signupPage.enterLastName("Tester");
        signupPage.enterEmail("name@name");
        signupPage.enterPassword("Test@12345");
    }

    @When("User clicks signup submit button")
    public void user_clicks_signup_submit_button() {
        signupPage.clickSubmit();
    }

    @Then("Registration should be successful")
    public void registration_should_be_successful() throws InterruptedException {
        Thread.sleep(1000);
        Assert.assertTrue(signupPage.isContactListDisplayed());
    }

    @Then("Signup error should be displayed")
    public void signup_error_should_be_displayed() {
        Assert.assertTrue(
                signupPage.isErrorDisplayed()
                || !signupPage.isContactListDisplayed()
        );
    }

    @Then("Signup validation should be displayed")
    public void signup_validation_should_be_displayed() {
        Assert.assertTrue(
                signupPage.isValidationDisplayed()
                || !signupPage.isContactListDisplayed()
        );
    }
}