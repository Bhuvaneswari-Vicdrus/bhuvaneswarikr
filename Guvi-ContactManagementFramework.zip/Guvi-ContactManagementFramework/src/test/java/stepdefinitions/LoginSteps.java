package stepdefinitions;

import org.junit.Assert;

import base.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.LoginPage;

public class LoginSteps {

    LoginPage loginPage = new LoginPage();

    @Given("User is on login page")
    public void user_is_on_login_page() {

        loginPage.openLoginPage();
    }

    @When("User enters valid email and password")
    public void user_enters_valid_email_and_password() {

        loginPage.enterEmail("12testmailid@gmail.com");

        loginPage.enterPassword("Test@12345");
    }

    @When("User clicks login button")
    public void user_clicks_login_button() {

        loginPage.clickLogin();
    }

    @Then("User should be redirected to contact list page")
    public void user_should_be_redirected_to_contact_list_page() {

    	 Assert.assertTrue(loginPage.isContactListPageDisplayed());
    }
    
    @When("User enters valid email and incorrect password")
    public void user_enters_valid_email_and_incorrect_password() {
        loginPage.enterEmail("12testmailid@test.com");
        loginPage.enterPassword("Password123");
    }

    @Then("Login error message should be displayed")
    public void login_error_message_should_be_displayed() {
        Assert.assertTrue(
                loginPage.isErrorDisplayed()
                || !loginPage.isContactListPageDisplayed()
        );
    }
    
 

    @Then("Login validation message should be displayed")
    public void login_validation_message_should_be_displayed() {
        Assert.assertTrue(
                loginPage.isEmailValidationDisplayed()
                || loginPage.isPasswordValidationDisplayed()
                || loginPage.isErrorDisplayed()
                || !loginPage.isContactListPageDisplayed()
        );
    }

    @When("User enters invalid email format")
    public void user_enters_invalid_email_format() {
        loginPage.enterEmail("user.com");
        loginPage.enterPassword("Test@12345");
    }

    @When("User enters password")
    public void user_enters_password() {
        loginPage.enterPassword("Test@12345");
    }

    @Then("Password field should mask input")
    public void password_field_should_mask_input() {
        Assert.assertEquals("password", loginPage.getPasswordFieldType());
    }
    
    @When("Application does not provide confirm password field")
    public void application_does_not_provide_confirm_password_field() {

        System.out.println(
            "Application does not contain Confirm Password field");
    }

    @Then("Test case should be marked as Not Applicable")
    public void test_case_should_be_marked_as_not_applicable() {

        Assert.assertTrue(true);
    }
}