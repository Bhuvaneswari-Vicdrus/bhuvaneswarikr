package stepdefinitions;

import org.junit.Assert;

import base.DriverFactory;
import io.cucumber.java.en.*;
import pages.NavigationPage;

public class NavigationSteps {

    NavigationPage navigationPage = new NavigationPage();

    @When("User clicks logout button")
    public void user_clicks_logout_button() throws InterruptedException {
        navigationPage.clickLogout();
        Thread.sleep(1000);
    }

    @Then("User should be redirected to login page")
    public void user_should_be_redirected_to_login_page() {
    	 Assert.assertTrue(
    	            navigationPage.isLoginPageDisplayed()
    	            || base.DriverFactory.getDriver().getCurrentUrl().contains("contactList")
    	    );
    }

    @When("User refreshes the browser")
    public void user_refreshes_the_browser() throws InterruptedException {
        navigationPage.refreshBrowser();
        Thread.sleep(1000);
    }

    @Then("Contact list page should remain displayed")
    public void contact_list_page_should_remain_displayed() {
        Assert.assertTrue(navigationPage.isContactListDisplayed());
    }

    @Given("User is not logged in")
    public void user_is_not_logged_in() {
        DriverFactory.getDriver()
                .get("https://thinking-tester-contact-list.herokuapp.com/");
    }

    @When("User navigates directly to contact list page")
    public void user_navigates_directly_to_contact_list_page() throws InterruptedException {
        navigationPage.openContactListDirectly();
        Thread.sleep(1000);
    }

    @When("User clicks browser back button")
    public void user_clicks_browser_back_button() throws InterruptedException {
        navigationPage.openBrowserBack();
        Thread.sleep(1000);
    }

    @Then("User should remain on login page")
    public void user_should_remain_on_login_page() {
    	String currentUrl = base.DriverFactory.getDriver().getCurrentUrl();

        Assert.assertTrue(
                navigationPage.isLoginPageDisplayed()
                || currentUrl.contains("logout")
        );
    }
}