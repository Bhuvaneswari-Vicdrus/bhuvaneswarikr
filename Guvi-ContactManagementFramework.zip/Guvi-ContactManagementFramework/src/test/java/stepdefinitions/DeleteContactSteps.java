package stepdefinitions;

import org.junit.Assert;

import io.cucumber.java.en.*;
import pages.DeleteContactPage;

public class DeleteContactSteps {

    DeleteContactPage deleteContactPage = new DeleteContactPage();

    @When("User opens a contact for deletion")
    public void user_opens_a_contact_for_deletion() throws InterruptedException {
        deleteContactPage.openContactForDeletion();
    }

    @When("User clicks delete contact button")
    public void user_clicks_delete_contact_button() {
        deleteContactPage.clickDeleteButton();
    }

    @When("User accepts delete confirmation")
    public void user_accepts_delete_confirmation() throws InterruptedException {
        deleteContactPage.acceptDeleteAlert();
        Thread.sleep(1000);
    }

    @Then("Contact should be removed from the list")
    public void contact_should_be_removed_from_the_list() {
        Assert.assertTrue(deleteContactPage.isContactListDisplayed());
    }

    @Then("Delete confirmation alert should appear")
    public void delete_confirmation_alert_should_appear() {
        Assert.assertTrue(deleteContactPage.isDeleteAlertDisplayed());

        deleteContactPage.acceptDeleteAlert();
    }

    @When("User refreshes contact list page")
    public void user_refreshes_contact_list_page() throws InterruptedException {
        deleteContactPage.refreshPage();
        Thread.sleep(1000);
    }

    @Then("Deleted contact should not appear")
    public void deleted_contact_should_not_appear() {
        Assert.assertTrue(deleteContactPage.isDeletedContactRemoved());
    }
}