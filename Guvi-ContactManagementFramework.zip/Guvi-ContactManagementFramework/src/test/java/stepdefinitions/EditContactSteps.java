package stepdefinitions;

import org.junit.Assert;

import io.cucumber.java.en.*;
import pages.EditContactPage;

public class EditContactSteps {

    EditContactPage editContactPage = new EditContactPage();

    @When("User opens an existing contact")
    public void user_opens_an_existing_contact() throws InterruptedException {
        Thread.sleep(1000);
        editContactPage.openEditTestContact();
    }

    @When("User clicks edit contact button")
    public void user_clicks_edit_contact_button() throws InterruptedException {
        Thread.sleep(1000);
        editContactPage.clickEditContact();
    }

    @When("User updates phone number")
    public void user_updates_phone_number() throws InterruptedException {
    	editContactPage.updatePhoneNumber();
    }

    @When("User clicks update contact button")
    public void user_clicks_update_contact_button() throws InterruptedException {
        editContactPage.clickUpdateContact();
        Thread.sleep(1000);
    }

    @Then("Updated contact details should be displayed")
    public void updated_contact_details_should_be_displayed() throws InterruptedException {

        Thread.sleep(1000);

        String currentUrl = base.DriverFactory.getDriver().getCurrentUrl();
        String pageSource = base.DriverFactory.getDriver().getPageSource().toLowerCase();

        System.out.println("After update URL: " + currentUrl);
        System.out.println("After update title: " + base.DriverFactory.getDriver().getTitle());

        Assert.assertTrue(
                currentUrl.contains("contactDetails")
        );
    }

    @When("User changes phone number without saving")
    public void user_changes_phone_number_without_saving() {
        editContactPage.changePhoneWithoutSaving();
    }

    @When("User clicks cancel edit button")
    public void user_clicks_cancel_edit_button() throws InterruptedException {
        editContactPage.clickCancelEdit();
        Thread.sleep(1000);
    }

    @Then("Original contact details should remain unchanged")
    public void original_contact_details_should_remain_unchanged() {
        Assert.assertTrue(editContactPage.isOriginalPhoneUnchanged());
    }

    @When("User removes last name")
    public void user_removes_last_name() {
        editContactPage.removeLastName();
    }

    @Then("Edit validation message should be displayed")
    public void edit_validation_message_should_be_displayed() {
        Assert.assertTrue(editContactPage.isEditValidationDisplayed());
    }
}