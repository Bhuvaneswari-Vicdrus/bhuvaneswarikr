package stepdefinitions;

import org.junit.Assert;

import io.cucumber.java.en.*;
import pages.AddContactPage;
import pages.LoginPage;

public class AddContactSteps {

    LoginPage loginPage = new LoginPage();
    AddContactPage addContactPage = new AddContactPage();

    @Given("User is logged in and on contact list page")
    public void user_is_logged_in_and_on_contact_list_page() throws InterruptedException {
        loginPage.openLoginPage();

        loginPage.enterEmail("12testmailid@gmail.com");
        loginPage.enterPassword("Test@12345");

        loginPage.clickLogin();

        Thread.sleep(1500);

        System.out.println("After login URL: " + base.DriverFactory.getDriver().getCurrentUrl());
        System.out.println("After login title: " + base.DriverFactory.getDriver().getTitle());

        Assert.assertTrue(loginPage.isContactListPageDisplayed());
    }

    @When("User clicks add new contact button")
    public void user_clicks_add_new_contact_button() {
        addContactPage.clickAddNewContact();
    }

    @When("User enters all valid contact details")
    public void user_enters_all_valid_contact_details() {
        addContactPage.enterValidContactDetails();
    }

    @When("User clicks contact submit button")
    public void user_clicks_contact_submit_button() {
        addContactPage.clickSubmit();
    }

    @Then("Contact should be added and visible in contact list")
    public void contact_should_be_added_and_visible_in_contact_list() throws InterruptedException {
    	Thread.sleep(2000);

        String currentUrl = base.DriverFactory.getDriver().getCurrentUrl();
        String pageSource = base.DriverFactory.getDriver().getPageSource();

        System.out.println("After add contact URL: " + currentUrl);
        System.out.println("After add contact page title: " + base.DriverFactory.getDriver().getTitle());

        Assert.assertTrue(
                currentUrl.contains("contactList")
        );
    }

    @Then("Contact validation message should be displayed")
    public void contact_validation_message_should_be_displayed() {
        Assert.assertTrue(addContactPage.isValidationDisplayed());
    }

    @When("User enters alphabets in phone number field")
    public void user_enters_alphabets_in_phone_number_field() {
        addContactPage.enterAlphabetsInPhone();
    }

    @Then("Phone field validation should be displayed")
    public void phone_field_validation_should_be_displayed() {
        Assert.assertTrue(addContactPage.isPhoneValidationDisplayed());
    }

    @When("User adds same contact details twice")
    public void user_adds_same_contact_details_twice() throws InterruptedException {
        addContactPage.clickAddNewContact();
        addContactPage.enterDuplicateContactDetails();
        addContactPage.clickSubmit();

        Thread.sleep(1000);

        addContactPage.clickAddNewContact();
        addContactPage.enterDuplicateContactDetails();
        addContactPage.clickSubmit();
    }

    @Then("Duplicate contact behavior should be documented")
    public void duplicate_contact_behavior_should_be_documented() {
        Assert.assertTrue(true);
    }

    @Then("Add contact form should be ready for new entry")
    public void add_contact_form_should_be_ready_for_new_entry() {
        Assert.assertTrue(addContactPage.isFormReadyForNewEntry());
    }
}